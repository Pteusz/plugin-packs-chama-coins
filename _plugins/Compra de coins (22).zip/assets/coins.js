/* Coins Selector — Slider por ÍNDICE + régua proporcional por segmento
 * - Lance: 100k em 100k até 1kk; 1kk em 1kk acima (+ "quebrados" via inject)
 * - Sniper: 100k em 100k até o limiar; 1kk em 1kk acima (limiar dinâmico)
 * - Slider trabalha por índice de passos válidos -> pontos uniformes em px
 * - Suporte a cupons/promoções via parâmetro promo
 * - NOVO: Suporte multi-moeda (detecta idioma do usuário e exibe preço na moeda correta)
 * - Limite de ~8 marcadores na escala para ambos os modos (distribuídos por valor)
 */
(function () {
  "use strict";

  var $$  = function (root, sel) { return root.querySelector(sel); };
  var $$$ = function (root, sel) { return Array.from(root.querySelectorAll(sel)); };
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };

  function debounce(fn, wait) {
    if (wait === void 0) wait = 200;
    var t;
    return function () {
      var args = arguments;
      clearTimeout(t);
      t = setTimeout(function(){ fn.apply(null, args); }, wait);
    };
  }

  var API = {
    get: async function (path, params) {
      params = params || {};
      var url = new URL(CSVARS.rest.root.replace(/\/$/, '') + '/' + path.replace(/^\//, ''));
      Object.entries(params).forEach(function(pair){
        var k = pair[0], v = pair[1];
        if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, v);
      });
      var res = await fetch(url.toString(), { headers: { 'X-WP-Nonce': CSVARS.rest.nonce } });
      if (!res.ok) throw new Error("HTTP " + res.status);
      return res.json();
    },
    post: async function (path, body) {
      body = body || {};
      var url = CSVARS.rest.root.replace(/\/$/, '') + '/' + path.replace(/^\//, '');
      var res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': CSVARS.rest.nonce },
        body: JSON.stringify(body)
      });
      if (!res.ok) {
        var err = {};
        try { err = await res.json(); } catch(e){}
        throw new Error(err && err.error ? err.error : "HTTP " + res.status);
      }
      return res.json();
    }
  };

  // formatador / parser
  function fmtCoinsShort(n) {
    if (n >= 1000000) {
      var kk = n / 1000000;
      var txt = (Math.round(kk) === kk ? kk.toFixed(0) : kk.toFixed(1)).replace('.', ',');
      return txt + 'kk';
    }
    return (n / 1000).toFixed(0) + 'k';
  }
  function parseCoins(str) {
    if (typeof str === 'number') return Math.max(0, Math.floor(str));
    var raw = String(str).trim().toLowerCase().replace(/\s+/g, '');

    if (/^\d+([.,]\d+)?kk$/.test(raw)) {
      var a = parseFloat(raw.replace('kk', '').replace(',', '.'));
      return Math.round(a * 1000000);
    }
    if (/^\d+([.,]\d+)?k$/.test(raw)) {
      var b = parseFloat(raw.replace('k', '').replace(',', '.'));
      return Math.round(b * 1000);
    }

    var num = raw.replace(/[^\d]/g, '');
    if (num) return Math.max(0, parseInt(num, 10));

    return 0;
  }

  function init(root) {
    var $input   = $$(root, '#cs-input');
    var $range   = $$(root, '#cs-range');
    var $scale   = $$(root, '[data-cs-scale]');
    var $coinsO  = $$(root, '[data-cs-out-coins]');
    var $priceO  = $$(root, '[data-cs-out-price]');
    var $finish  = $$(root, '[data-cs-finish]');
    var $platformSel = $$(root, '#cs-platform');
    var $modes   = $$$ (root, '.cs-mode');

    // Setas (desktop e mobile)
    var $arrowsL = $$$ (root, '[data-cs-left]');
    var $arrowsR = $$$ (root, '[data-cs-right]');

    // Bônus (linha extra opcional)
    var $bonusO  = $$(root, '[data-cs-out-bonus]');

    // Badge de promoção (opcional)
    var $promoBadge = $$(root, '[data-cs-promo-badge]');

    // Código do cupom (vem do CSVARS)
    var promoCode = (CSVARS && CSVARS.promo) ? String(CSVARS.promo) : '';

    var state = {
      mode: 'lance',
      platform: 'ps',
      index: 0,
      coins: 300000,
      limits: null,
      has50k: false,
      allowed: [],
      dragging: false,
      isTyping: false,
      busy: false,
      promo: promoCode,
      // NOVO: informações de moeda detectadas do backend
      currencySymbol: 'R$',
      currencyCode: 'BRL'
    };

    var calcSeq = 0;

    // Exibe badge de promoção se existir
    function updatePromoBadge() {
      if ($promoBadge) {
        if (state.promo) {
          $promoBadge.textContent = state.promo;
          $promoBadge.style.display = '';
        } else {
          $promoBadge.style.display = 'none';
        }
      }
    }

    function toggleModeUI() {
      $modes.forEach(function(btn){
        var on = btn.dataset.mode === state.mode;
        btn.classList.toggle('is-active', on);
        btn.setAttribute('aria-selected', String(on));
      });
      var isSniper = state.mode === 'sniper';
      root.classList.toggle('is-sniper', isSniper);
      Array.from(root.querySelectorAll('.cs-sniper-arrows, .cs-mobile-arrows')).forEach(function(el){
        el.setAttribute('aria-hidden', String(!isSniper));
      });
    }

    function applyPlatformSkin(){
      root.setAttribute('data-pf', state.platform);
    }

    function roundUpTo(v, step) { return Math.ceil(v / step) * step; }

    function buildAllowedValues() {
      if (!state.limits) return [];
      var minEff = effectiveMin();
      var max    = Number(state.limits.max);
      var thr    = (state.mode === 'sniper') ? Number(state.limits.threshold || 10000000) : 1000000;

      var out = [];
      if (state.has50k) out.push(50000);

      var startBelow = Math.max(100000, minEff);
      startBelow = roundUpTo(startBelow, 100000);

      if (state.mode === 'sniper') {
        var th = Math.max(minEff, Math.min(thr, max));
        for (var v = startBelow; v <= Math.min(th, max); v += 100000) out.push(v);
        if (max >= th) {
          var base = Math.max(th, 1000000);
          var first = roundUpTo(base, 1000000);
          for (var v2 = first; v2 <= max; v2 += 1000000) out.push(v2);
        }
      } else {
        var thL = 1000000;
        for (var v3 = startBelow; v3 <= Math.min(thL, max); v3 += 100000) out.push(v3);
        if (max >= thL) {
          var firstL = roundUpTo(thL, 1000000);
          for (var v4 = firstL; v4 <= max; v4 += 1000000) out.push(v4);
        }
      }

      if (state.mode === 'lance' && state.limits && Array.isArray(state.limits.inject) && state.limits.inject.length) {
        for (var i = 0; i < state.limits.inject.length; i++) {
          var val = Number(state.limits.inject[i]);
          if (!isNaN(val)) out.push(val);
        }
      }

      out.push(minEff, max);
      out = Array.from(new Set(out)).sort(function(a,b){return a-b;});
      out = out.filter(function(v){ return v >= minEff && v <= max; });
      return out;
    }

    function nearestIndex(value) {
      var arr = state.allowed;
      if (!arr || arr.length === 0) return 0;
      if (value <= arr[0]) return 0;
      if (value >= arr[arr.length - 1]) return arr.length - 1;
      var best = 0, bestD = Infinity;
      for (var i = 0; i < arr.length; i++) {
        var d = Math.abs(arr[i] - value);
        if (d < bestD) { bestD = d; best = i; }
      }
      return best;
    }

    function valueAt(idx) {
      if (!state.allowed || state.allowed.length === 0) return 0;
      idx = clamp(idx, 0, state.allowed.length - 1);
      return state.allowed[idx];
    }

    function effectiveMin() {
      return state.has50k ? 50000 : Math.max(100000, Number(state.limits && state.limits.min || 100000));
    }

    function setRangeAttrs() {
      if (!state.limits) return;
      var n = state.allowed.length;
      if (n < 2) {
        $range.min = '0';
        $range.max = '0';
        $range.step = '1';
        $range.value = '0';
        updateRangeVisuals();
        return;
      }
      $range.min  = '0';
      $range.max  = String(n - 1);
      $range.step = '1';
      $range.value = String(state.index);
      updateRangeVisuals();
    }

    function setRangeValue(idx) { $range.value = String(idx); }
    function setInputValue(v) { $input.value = fmtCoinsShort(v); }

    function updateVisor(calc) {
      var base  = Number(calc.coins || 0);
      var bonus = Number(calc.bonus_coins || 0);
      var total = Number(calc.total_coins || base);
      var show  = bonus > 0 ? total : base;

      // NOVO: Atualiza moeda do estado se retornada pelo backend
      if (calc.currency_symbol) {
        state.currencySymbol = calc.currency_symbol;
      }
      if (calc.currency_code) {
        state.currencyCode = calc.currency_code;
      }

      if ($coinsO) {
        $coinsO.textContent = fmtCoinsShort(show);
      }
      if ($priceO) {
        // NOVO: Usa price_formatted se disponível, senão usa price_brl
        var priceText = calc.price_formatted || calc.price_brl || '';
        $priceO.textContent = priceText;
      }

      if ($bonusO) {
        if (bonus > 0) {
          $bonusO.textContent = 'Bônus: ' + fmtCoinsShort(bonus);
          $bonusO.style.display = '';
        } else {
          $bonusO.textContent = '';
          $bonusO.style.display = 'none';
        }
      }
    }

    // ------ Visual do range (preenchimento/track) ------
    function updateRangeVisuals() {
      var denom = Math.max(1, (state.allowed.length - 1));
      var pct = (clamp(state.index, 0, denom) / denom) * 100;
      $range.style.setProperty('--cs-range-pct', pct + '%');
    }
    function emitRangeEvents() {
      $range.dispatchEvent(new Event('input',  { bubbles: true }));
      $range.dispatchEvent(new Event('change', { bubbles: true }));
    }
    async function syncToIndex(idx, opts) {
      opts = opts || {};
      var n = state.allowed.length;
      var clamped = clamp(Number(idx), 0, Math.max(0, n - 1));
      state.index = clamped;
      state.coins = valueAt(state.index);
      setRangeValue(state.index);
      updateRangeVisuals();
      if (!state.isTyping) setInputValue(state.coins);
      if (!opts.skipEmit) emitRangeEvents();
      if (opts.debounced) { doCalcDebounced(); }
      else { await doCalc(); }
    }

    // ---------- Escala (LIMITE DE 8 MARCADORES - DISTRIBUÍDOS POR VALOR) ----------
  function buildScale() {
  if (!$scale || !state.limits || !state.allowed || state.allowed.length < 2) {
    if ($scale) $scale.innerHTML = '';
    return;
  }

  $scale.innerHTML = '';

  var n = state.allowed.length;
  var minVal = state.allowed[0];
  var maxVal = state.allowed[n - 1];

  var MAX_LABELS = 8;

  function addTick(pct, label, forceLabel) {
    var el = document.createElement('span');
    el.className = 'cs-tick' + (forceLabel ? ' has-label' : '');
    el.style.left = pct + '%';
    if (forceLabel) el.dataset.label = label;
    $scale.appendChild(el);
  }

  function valueAtPct(t01) {
    var idxF = t01 * (n - 1);
    var i0 = Math.floor(idxF);
    var i1 = Math.ceil(idxF);
    var frac = idxF - i0;

    var v0 = state.allowed[i0];
    var v1 = state.allowed[i1];

    return (v0 + (v1 - v0) * frac);
  }

  // Quantização "bonita" dos labels (sem quebrado)
  function quantizeLabelValue(raw) {
    raw = Number(raw) || 0;

    // Sniper muda passo depois do threshold; Lance muda depois de 1kk
    var th = (state.mode === 'sniper')
      ? Number(state.limits.threshold || 10000000)
      : 1000000;

    var step = (raw < th) ? 100000 : 1000000;

    // arredonda pro step (100k ou 1kk)
    var q = Math.round(raw / step) * step;

    // clamp no range
    q = clamp(q, minVal, maxVal);

    // snap pro permitido mais próximo (garante que existe em state.allowed)
    var idx = nearestIndex(q);
    return valueAt(idx);
  }

  var usedLabels = new Set();

  for (var i = 0; i < MAX_LABELS; i++) {
    var t = (MAX_LABELS === 1) ? 0 : (i / (MAX_LABELS - 1));
    var pct = t * 100;

    var val;
    if (i === 0) val = minVal;
    else if (i === MAX_LABELS - 1) val = maxVal;
    else val = quantizeLabelValue(valueAtPct(t));

    var label = fmtCoinsShort(val);

    // se repetir label, mantém o tick mas sem texto
    var canLabel = !usedLabels.has(label);
    if (canLabel) usedLabels.add(label);

    addTick(pct, label, canLabel);
  }
}


    // ===== REST + interações =====
    async function detectHas50k() {
      try {
        var params = { mode: state.mode, platform: state.platform, coins: 50000 };
        if (state.promo) params.promo = state.promo;
        var res = await API.get('calc', params);
        state.has50k = !!res.is_50k;
      } catch (e) { state.has50k = false; }
    }

    // opts: { forceStart: boolean }
    async function refreshLimits(adjustCoins, opts) {
      opts = opts || {};
      if (adjustCoins === void 0 || adjustCoins === null) adjustCoins = state.coins;

      var params = { mode: state.mode, platform: state.platform, coins: adjustCoins };
      if (state.promo) params.promo = state.promo;

      var res = await API.get('limits', params);
      state.limits = {
        min: Number(res.min),
        max: Number(res.max),
        threshold: (state.mode === 'sniper') ? Number(res.threshold || 10000000) : 1000000,
        inject: Array.isArray(res.inject) ? res.inject.map(function(n){ return Number(n)||0; }).filter(Boolean) : []
      };

      await detectHas50k();

      state.allowed = buildAllowedValues();
      if (!state.allowed || state.allowed.length === 0) state.allowed = [adjustCoins];

      if (opts.forceStart) {
        state.index = 0;
        state.coins = valueAt(0);
      } else {
        state.index = nearestIndex(adjustCoins);
        state.coins = valueAt(state.index);
      }

      setRangeAttrs();
      requestAnimationFrame(function(){ buildScale(); });

      if (!state.isTyping) setInputValue(state.coins);
      updateRangeVisuals();
    }

    async function doCalc() {
      var id = ++calcSeq;
      try {
        var params = { mode: state.mode, platform: state.platform, coins: state.coins };
        if (state.promo) params.promo = state.promo;
        var res = await API.get('calc', params);
        if (id !== calcSeq) return;
        updateVisor(res);
      } catch (e) { console.warn('calc error:', e); }
    }
    var doCalcDebounced = debounce(doCalc, 140);

    async function finalizeGesture(idxRaw) {
      await syncToIndex(idxRaw, { debounced: false, skipEmit: true });
    }

    $modes.forEach(function(btn){
      btn.addEventListener('click', async function () {
        var m = btn.dataset.mode;
        if (m === state.mode) return;
        state.mode = m;
        toggleModeUI();
        await refreshLimits(state.coins);
        await doCalc();
      });
    });

    $platformSel.addEventListener('change', async function () {
      state.platform = $platformSel.value;
      applyPlatformSkin();
      await refreshLimits(state.coins);
      await doCalc();
    });

    $input.addEventListener('focus', function(){ state.isTyping = true; });
    $input.addEventListener('blur',  function(){
      state.isTyping = false;
      setInputValue(state.coins);
    });

    // Digitação: aceita 500k, 2kk, 150000, 1,5kk...
    var onType = debounce(async function(){
      var desired = parseCoins($input.value);
      if (desired > 0) {
        var idx = nearestIndex(desired);
        await syncToIndex(idx, { debounced: true });
      }
    }, 160);
    $input.addEventListener('input', onType);

    $input.addEventListener('keydown', async function(e){
      if (e.key === 'Enter') {
        e.preventDefault();
        var desired = parseCoins($input.value);
        if (desired > 0) {
          var idx = nearestIndex(desired);
          await syncToIndex(idx, { debounced: false });
        }
      }
    });

    function startDrag() { state.dragging = true; }
    function endDrag()   { state.dragging = false; finalizeGesture($range.value); }

    $range.addEventListener('pointerdown', startDrag, { passive: true });
    window.addEventListener('pointerup', endDrag, { passive: true });
    $range.addEventListener('mousedown', startDrag, { passive: true });
    window.addEventListener('mouseup', endDrag, { passive: true });
    $range.addEventListener('touchstart', startDrag, { passive: true });
    window.addEventListener('touchend', endDrag, { passive: true });

    $range.addEventListener('input', function(){
      var idx = Number($range.value) || state.index;
      state.index = clamp(idx, 0, Math.max(0, (state.allowed.length - 1)));
      state.coins = valueAt(state.index);
      updateRangeVisuals();
      if (!state.isTyping) setInputValue(state.coins);
      doCalcDebounced();
    });

    async function stepBy(dir) {
      var n = state.allowed.length;
      var next = clamp(state.index + dir, 0, Math.max(0, n - 1));
      await syncToIndex(next, { debounced: false });
    }

    $arrowsL.forEach(function(btn){
      btn.addEventListener('click', function(e){
        e.preventDefault();
        stepBy(-1);
      });
    });
    $arrowsR.forEach(function(btn){
      btn.addEventListener('click', function(e){
        e.preventDefault();
        stepBy(+1);
      });
    });

    async function finalize() {
      if (state.busy) return;
      try {
        state.busy = true;
        var body = { mode: state.mode, platform: state.platform, coins: state.coins };
        if (state.promo) body.promo = state.promo;
        var res = await API.post('finalize', body);
        if (res && res.redirect) window.location.href = res.redirect;
      } catch (e) { alert(e.message || 'Não foi possível finalizar.'); }
      finally { state.busy = false; }
    }
    $finish.addEventListener('click', finalize);

    var onResize = debounce(function(){
      buildScale();
      updateRangeVisuals();
      if (!state.isTyping) setInputValue(state.coins);
    }, 150);
    window.addEventListener('resize', onResize);

    // Boot
    (async function boot() {
      toggleModeUI();
      applyPlatformSkin();
      updatePromoBadge();
      await refreshLimits(null, { forceStart: true });
      setInputValue(state.coins);
      updateRangeVisuals();
      await doCalc();
    })();
  }

  window.addEventListener('DOMContentLoaded', function(){
    $$$ (document, '[data-cs-root]').forEach(init);
  });
})();