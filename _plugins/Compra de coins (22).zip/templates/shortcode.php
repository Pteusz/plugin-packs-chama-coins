<?php
/**
 * Template do shortcode [coins_selector]
 * Estrutura HTML compatível com o CSS original
 */
if ( ! defined('ABSPATH') ) exit;

// Detecta se há promoção ativa
$promo_code = '';
$promo_name = '';
if ( isset($_GET['promo']) && !empty($_GET['promo']) ) {
    $promo_code = sanitize_text_field($_GET['promo']);
    $promo_data = CS_Core::get_promo_by_code($promo_code);
    if ( $promo_data && !empty($promo_data['active']) ) {
        $promo_name = !empty($promo_data['name']) ? $promo_data['name'] : $promo_code;
    } else {
        $promo_code = '';
    }
}
?>
<div class="cs-outer-wrapper">

    <?php if ( !empty($promo_code) ) : ?>
        <span class="cs-promo-tag" data-cs-promo-badge><?php echo esc_html($promo_code); ?></span>
    <?php else : ?>
        <span class="cs-promo-tag" data-cs-promo-badge style="display:none;"></span>
    <?php endif; ?>

    <div class="cs-wrapper" data-cs-root data-pf="ps">

        <div class="cs-inner">

            <!-- Linha 1: Busca/Input -->
            <div class="cs-row cs-search">
                <div class="cs-searchbox">
                    <svg class="cs-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="11" cy="11" r="8"/>
                        <path d="m21 21-4.35-4.35"/>
                    </svg>
                    <input type="text" id="cs-input" inputmode="text" autocomplete="off" placeholder="100k" />
                </div>
            </div>

            <!-- Linha 2: Modos + Plataforma + Visor -->
            <div class="cs-row cs-controls">
                <div class="cs-modes" role="tablist">
                    <button type="button" class="cs-mode is-active" data-mode="lance" role="tab" aria-selected="true">
                        Buy Now
                    </button>
                    <button type="button" class="cs-mode" data-mode="sniper" role="tab" aria-selected="false">
                        Sniper
                    </button>
                </div>

                <div class="cs-platform">
                    <select id="cs-platform">
                        <option value="ps">PlayStation</option>
                        <option value="xbox">Xbox</option>
                        <option value="pc">PC</option>
                    </select>
                </div>

                <div class="cs-visor">
                    <span class="cs-visor-title">Total de Coins</span>
                    <span class="cs-visor-coins" data-cs-out-coins>100k</span>
                   <span class="cs-visor-bonus" data-cs-out-bonus style="display:none;">Bônus:</span>
                    <span class="cs-visor-price" data-cs-out-price>R$ 0,00</span>
                </div>
            </div>

            <!-- Linha 3: Slider -->
            <div class="cs-row cs-slider">
                <div class="cs-actions">
                    <button type="button" class="cs-finish" data-cs-finish>Finalizar</button>
                </div>

                <!-- Seta esquerda (desktop/sniper) -->
                <div class="cs-sniper-arrows" aria-hidden="true">
                    <button type="button" class="cs-arrow" data-cs-left aria-label="Diminuir">‹</button>
                </div>

                <!-- Trilho do slider -->
                <div class="cs-range">
                    <input type="range" id="cs-range" min="0" max="100" step="1" value="0" />
                    <div class="cs-scale" data-cs-scale></div>
                </div>

                <!-- Seta direita (desktop/sniper) -->
                <div class="cs-sniper-arrows" aria-hidden="true">
                    <button type="button" class="cs-arrow" data-cs-right aria-label="Aumentar">›</button>
                </div>

                <!-- Setas mobile (aparecem só no modo Sniper em telas pequenas) -->
                <div class="cs-mobile-arrows" aria-hidden="true">
                    <button type="button" class="cs-mbtn cs-mbtn-left" data-cs-left aria-label="Diminuir">‹</button>
                    <button type="button" class="cs-mbtn cs-mbtn-right" data-cs-right aria-label="Aumentar">›</button>
                </div>
            </div>

        </div>
    </div>
</div>