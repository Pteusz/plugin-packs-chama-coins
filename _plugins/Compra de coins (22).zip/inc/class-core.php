<?php
if ( ! defined('ABSPATH') ) exit;

/**
 * Coins Selector — Core
 * - Cálculo de limites / preço / bônus
 * - Suporte a cupons/promoções
 * - NOVO: Detecção de idioma/moeda via sistema de tradução (TMTR)
 * - Conversão automática BRL → USD/EUR conforme idioma do usuário
 * - Finalização Buy Now -> cria token + redireciona para formulário (igual ao Sniper)
 * - Sniper -> cria token + redireciona para formulário
 * - Hooks WC para preço dinâmico + metas visíveis (descrição/coins) + meta oculta (_cs_buynow_token)
 */

class CS_Core {

    /* ============================================================
     * BOOT / HOOKS WC
     * ============================================================ */
    public static function boot_wc_hooks() {
        // Define/prepara preços dinâmicos em toda página que calcula totais
        self::hook_cart_item_price();

        // Exibe o nome customizado do item quando existir cs_label (prioridade alta)
        add_filter('woocommerce_cart_item_name', function($prod_name, $cart_item){
            if ( ! empty($cart_item['cs_label']) ) {
                return esc_html($cart_item['cs_label']);
            }
            return $prod_name;
        }, 999, 2);

        // Mostra a descrição sob o item no carrinho/checkout quando existir cs_desc
        add_filter('woocommerce_get_item_data', function($data, $cart_item){
            if ( isset($cart_item['cs_desc']) ) {
                $data[] = [
                    'key'     => 'Descrição',
                    'value'   => esc_html($cart_item['cs_desc']),
                    'display' => esc_html($cart_item['cs_desc']),
                ];
            }
            if ( isset($cart_item['cs_total_coins']) ) {
                $data[] = [
                    'key'     => 'Total de Coins',
                    'value'   => esc_html( self::format_coins_label((int)$cart_item['cs_total_coins']) ),
                    'display' => esc_html( self::format_coins_label((int)$cart_item['cs_total_coins']) ),
                ];
            }
            if ( ! empty($cart_item['cs_bonus_coins']) ) {
                $data[] = [
                    'key'     => 'Bônus de Coins',
                    'value'   => esc_html( self::format_coins_label((int)$cart_item['cs_bonus_coins']) ),
                    'display' => esc_html( self::format_coins_label((int)$cart_item['cs_bonus_coins']) ),
                ];
            }
            // Mostra cupom usado se houver
            if ( ! empty($cart_item['cs_promo_code']) ) {
                $data[] = [
                    'key'     => 'Cupom',
                    'value'   => esc_html($cart_item['cs_promo_code']),
                    'display' => esc_html($cart_item['cs_promo_code']),
                ];
            }
            return $data;
        }, 10, 2);

        // Persiste a descrição e info de coins/bônus na ordem
        add_action('woocommerce_checkout_create_order_line_item', function($item, $cart_item_key, $values){
            if ( isset($values['cs_desc']) ) {
                $item->add_meta_data('Descrição', (string)$values['cs_desc'], true);
            }
            if ( isset($values['cs_total_coins']) ) {
                $item->add_meta_data(
                    'Total de Coins',
                    self::format_coins_label((int)$values['cs_total_coins']),
                    true
                );
            }
            if ( ! empty($values['cs_bonus_coins']) ) {
                $item->add_meta_data(
                    'Bônus de Coins',
                    self::format_coins_label((int)$values['cs_bonus_coins']),
                    true
                );
            }
            // Salva cupom usado
            if ( ! empty($values['cs_promo_code']) ) {
                $item->add_meta_data('Cupom', (string)$values['cs_promo_code'], true);
            }

            /**
             * Token interno do Buy Now (oculto):
             * - Meta com "_" não aparece pro cliente por padrão.
             * - Fica disponível para admin e para cruzar com wp_cs_buynow_orders.
             */
            if ( ! empty($values['cs_buynow_token']) ) {
                $item->add_meta_data('_cs_buynow_token', (string)$values['cs_buynow_token'], true);
            }
        }, 10, 3);
    }

    /* ============================================================
     * CONFIG / DB (TABELAS)
     * ============================================================ */

    public static function table_config() {
        global $wpdb;
        return $wpdb->prefix . 'cs_config';
    }

    public static function table_sniper_orders() {
        global $wpdb;
        return $wpdb->prefix . 'cs_sniper_orders';
    }

    public static function table_buynow_orders() {
        global $wpdb;
        return $wpdb->prefix . 'cs_buynow_orders';
    }

    public static function table_schedules() {
        global $wpdb;
        return $wpdb->prefix . 'cs_config_schedules';
    }

    public static function table_promos() {
        global $wpdb;
        return $wpdb->prefix . 'cs_promos';
    }

    public static function table_price_tiers() {
        global $wpdb;
        return $wpdb->prefix . 'cs_price_tiers';
    }

    /**
     * Retorna as faixas de preço de um modo/plataforma ordenadas por coins_min ASC.
     */
    public static function get_tiers( string $mode, string $platform ) : array {
        global $wpdb;
        $tbl = self::table_price_tiers();

        $table_exists = $wpdb->get_var(
            $wpdb->prepare( "SHOW TABLES LIKE %s", $tbl )
        );
        if ( $table_exists !== $tbl ) {
            return [];
        }

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, coins_min, coins_max, price_100k FROM {$tbl}
             WHERE mode = %s AND platform = %s
             ORDER BY coins_min ASC",
            $mode, $platform
        ), ARRAY_A );

        return $rows ? $rows : [];
    }

    /**
     * Retorna o price_100k da faixa que cobre $coins, ou null se não houver faixa.
     * Apenas consultado quando não há promo ativa.
     */
    public static function get_price_for_coins( string $mode, string $platform, int $coins ) : ?float {
        global $wpdb;
        $tbl = self::table_price_tiers();

        $table_exists = $wpdb->get_var(
            $wpdb->prepare( "SHOW TABLES LIKE %s", $tbl )
        );
        if ( $table_exists !== $tbl ) {
            return null;
        }

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT price_100k FROM {$tbl}
             WHERE mode = %s AND platform = %s
               AND coins_min <= %d
               AND ( coins_max IS NULL OR coins_max >= %d )
             ORDER BY coins_min DESC
             LIMIT 1",
            $mode, $platform, $coins, $coins
        ), ARRAY_A );

        return $row ? (float) $row['price_100k'] : null;
    }

    /* ============================================================
     * MULTI-MOEDA / DETECÇÃO DE IDIOMA
     * ============================================================ */

    /**
     * Detecta idioma do usuário via sistema de tradução (TMTR_Language_Resolver)
     * e retorna informações de moeda correspondente.
     * 
     * @return array ['lang' => 'pt-BR', 'currency_code' => 'BRL', 'currency_symbol' => 'R$', 'exchange_rate' => 1.0]
     */
    protected static function detect_user_currency() : array {
        // Padrão fallback (BRL)
        $default = [
            'lang'            => 'pt-BR',
            'currency_code'   => 'BRL',
            'currency_symbol' => 'R$',
            'exchange_rate'   => 1.0,
        ];

        // Tenta detectar idioma via sistema de tradução
        $lang = 'pt-BR';
        if ( class_exists('TMTR_Language_Resolver') && method_exists('TMTR_Language_Resolver', 'get_current_lang') ) {
            $detected = TMTR_Language_Resolver::get_current_lang();
            if ( $detected && is_string($detected) && trim($detected) !== '' ) {
                $lang = trim($detected);
            }
        }

        // Mapeia idioma → moeda
        return self::map_lang_to_currency($lang);
    }

    /**
     * Mapeia um código de idioma para moeda correspondente.
     * 
     * @param string $lang Código do idioma (ex: 'pt-BR', 'en-US', 'es-ES')
     * @return array
     */
    protected static function map_lang_to_currency( string $lang ) : array {
        $lang = strtolower( str_replace('_', '-', trim($lang)) );

        // Mapeamento idioma → moeda
        $map = [
            // Português
            'pt-br' => ['code' => 'BRL', 'symbol' => 'R$',  'rate' => 1.0],
            'pt-pt' => ['code' => 'EUR', 'symbol' => '€',   'rate' => 0.17], // aprox 6.0 BRL/EUR
            
            // Inglês
            'en-us' => ['code' => 'USD', 'symbol' => '$',   'rate' => 0.19], // aprox 5.3 BRL/USD
            'en-gb' => ['code' => 'GBP', 'symbol' => '£',   'rate' => 0.15], // aprox 6.7 BRL/GBP
            'en-ca' => ['code' => 'CAD', 'symbol' => 'C$',  'rate' => 0.26], // aprox 3.9 BRL/CAD
            
            // Espanhol
            'es-es' => ['code' => 'EUR', 'symbol' => '€',   'rate' => 0.17],
            'es-mx' => ['code' => 'MXN', 'symbol' => 'MX$', 'rate' => 3.70], // aprox 0.27 BRL/MXN
            
            // Europeu (Euro)
            'fr-fr' => ['code' => 'EUR', 'symbol' => '€',   'rate' => 0.17],
            'de-de' => ['code' => 'EUR', 'symbol' => '€',   'rate' => 0.17],
            'it-it' => ['code' => 'EUR', 'symbol' => '€',   'rate' => 0.17],
            'nl-nl' => ['code' => 'EUR', 'symbol' => '€',   'rate' => 0.17],
            
            // Outros
            'tr-tr' => ['code' => 'TRY', 'symbol' => '₺',   'rate' => 6.20], // aprox 0.16 BRL/TRY
            'pl-pl' => ['code' => 'PLN', 'symbol' => 'zł',  'rate' => 0.77], // aprox 1.3 BRL/PLN
            'sv-se' => ['code' => 'SEK', 'symbol' => 'kr',  'rate' => 2.05], // aprox 0.49 BRL/SEK
            'ar-sa' => ['code' => 'SAR', 'symbol' => '﷼',   'rate' => 0.71], // aprox 1.4 BRL/SAR
        ];

        // Busca correspondência exata
        if ( isset($map[$lang]) ) {
            return array_merge([
                'lang' => $lang,
                'currency_code'   => $map[$lang]['code'],
                'currency_symbol' => $map[$lang]['symbol'],
                'exchange_rate'   => $map[$lang]['rate'],
            ]);
        }

        // Tenta match por base do idioma (ex: 'pt' de 'pt-BR')
        $base = explode('-', $lang)[0];
        foreach ( $map as $key => $data ) {
            if ( strpos($key, $base . '-') === 0 ) {
                return array_merge([
                    'lang' => $lang,
                    'currency_code'   => $data['code'],
                    'currency_symbol' => $data['symbol'],
                    'exchange_rate'   => $data['rate'],
                ]);
            }
        }

        // Fallback: BRL
        return [
            'lang'            => $lang,
            'currency_code'   => 'BRL',
            'currency_symbol' => 'R$',
            'exchange_rate'   => 1.0,
        ];
    }

    /**
     * Formata um valor monetário conforme a moeda.
     * 
     * @param float  $value
     * @param string $currency_code
     * @param string $currency_symbol
     * @return string
     */
    public static function format_price( $value, $currency_code = 'BRL', $currency_symbol = 'R$' ) : string {
        $value = (float) $value;

        // Formato específico por moeda
        switch ( strtoupper($currency_code) ) {
            case 'BRL':
                return 'R$ ' . number_format($value, 2, ',', '.');
            
            case 'USD':
            case 'CAD':
                return '$' . number_format($value, 2, '.', ',');
            
            case 'GBP':
                return '£' . number_format($value, 2, '.', ',');
            
            case 'EUR':
                return '€' . number_format($value, 2, ',', '.');
            
            case 'MXN':
                return 'MX$' . number_format($value, 2, '.', ',');
            
            default:
                // Genérico: símbolo + valor
                return $currency_symbol . ' ' . number_format($value, 2, '.', ',');
        }
    }

    /**
     * Traduz textos simples conforme idioma.
     * 
     * @param string $key   Chave de tradução
     * @param string $lang  Código do idioma
     * @return string
     */
    protected static function translate_text( string $key, string $lang ) : string {
        $lang = strtolower( str_replace('_', '-', trim($lang)) );
        
        $translations = [
            'buy_now_mode' => [
                'pt-br' => 'Modo Buy Now',
                'en-us' => 'Buy Now Mode',
                'es-es' => 'Modo Compra Directa',
                'fr-fr' => 'Mode Achat Direct',
                'de-de' => 'Direktkauf-Modus',
                'it-it' => 'Modalità Acquisto Diretto',
            ],
            'for_platform' => [
                'pt-br' => 'para',
                'en-us' => 'for',
                'es-es' => 'para',
                'fr-fr' => 'pour',
                'de-de' => 'für',
                'it-it' => 'per',
            ],
            'bonus' => [
                'pt-br' => 'bônus',
                'en-us' => 'bonus',
                'es-es' => 'bono',
                'fr-fr' => 'bonus',
                'de-de' => 'Bonus',
                'it-it' => 'bonus',
            ],
            'total' => [
                'pt-br' => 'total',
                'en-us' => 'total',
                'es-es' => 'total',
                'fr-fr' => 'total',
                'de-de' => 'gesamt',
                'it-it' => 'totale',
            ],
            'coupon' => [
                'pt-br' => 'Cupom',
                'en-us' => 'Coupon',
                'es-es' => 'Cupón',
                'fr-fr' => 'Coupon',
                'de-de' => 'Gutschein',
                'it-it' => 'Buono',
            ],
        ];

        if ( isset($translations[$key][$lang]) ) {
            return $translations[$key][$lang];
        }

        // Tenta base do idioma
        $base = explode('-', $lang)[0];
        foreach ( $translations[$key] ?? [] as $k => $v ) {
            if ( strpos($k, $base . '-') === 0 ) {
                return $v;
            }
        }

        // Fallback: inglês
        return $translations[$key]['en-us'] ?? $key;
    }

    /* ============================================================
     * HELPERS (STRINGS / FORMATAÇÃO)
     * ============================================================ */

    protected static function ends_with(string $haystack, string $needle): bool {
        if ($needle === '') return true;
        $len = strlen($needle);
        if ($len === 0) return true;
        return substr($haystack, -$len) === $needle;
    }

    protected static function safe_token(int $bytes = 12): string {
        try {
            return bin2hex(random_bytes($bytes));
        } catch (\Throwable $e) {
            return (string) wp_generate_password($bytes * 2, false, false);
        }
    }

    public static function parse_coins( $input ) : int {
        if ( is_numeric($input) ) {
            return max(0, (int)$input);
        }

        $str = strtolower( trim( (string)$input ) );

        // normaliza: "1,5kk" -> "1.5kk", remove espaços e pontos separadores
        $str = str_replace([' ', "\t", "\n", "\r"], '', $str);
        // remove pontos de milhar e troca vírgula por ponto (decimal)
        $str = preg_replace('/\.(?=\d{3}(\D|$))/', '', $str);
        $str = str_replace(',', '.', $str);

        if ( self::ends_with($str, 'kk') ) {
            $num = (float) str_replace('kk', '', $str);
            return (int) round($num * 1000000);
        }
        if ( self::ends_with($str, 'k') ) {
            $num = (float) str_replace('k', '', $str);
            return (int) round($num * 1000);
        }

        // fallback: só dígitos
        $digits = preg_replace('/[^\d]/', '', $str);
        return max(0, (int)$digits);
    }

    public static function format_brl( $value ) : string {
        return 'R$ ' . number_format((float)$value, 2, ',', '.');
    }

    public static function format_coins_label( int $coins ) : string {
        if ($coins >= 1000000) {
            $kk = $coins / 1000000;
            $txt = (round($kk) == $kk)
                ? number_format($kk, 0, ',', '')
                : str_replace('.', ',', number_format($kk, 1, '.', ''));
            return $txt . 'kk';
        }
        return number_format($coins / 1000, 0, ',', '') . 'k';
    }

    /* ============================================================
     * PROMOÇÕES / CUPONS
     * ============================================================ */

    /**
     * Busca uma promoção pelo código
     */
    public static function get_promo_by_code( string $code ) : ?array {
        if ( empty($code) ) return null;

        global $wpdb;
        $tbl = self::table_promos();

        // Verifica se tabela existe
        $table_exists = $wpdb->get_var(
            $wpdb->prepare("SHOW TABLES LIKE %s", $tbl)
        );
        if ( $table_exists !== $tbl ) {
            return null;
        }

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $tbl WHERE code = %s LIMIT 1", $code),
            ARRAY_A
        );

        if ( !$row ) return null;

        // Verifica expiração
        if ( !empty($row['expires_at']) && $row['expires_at'] !== '0000-00-00 00:00:00' ) {
            $now = current_time('mysql');
            if ( $row['expires_at'] < $now ) {
                return null; // Expirado
            }
        }

        // Decodifica config_json
        $row['config'] = [];
        if ( !empty($row['config_json']) ) {
            $decoded = json_decode($row['config_json'], true);
            if ( is_array($decoded) ) {
                $row['config'] = $decoded;
            }
        }

        return $row;
    }

    /**
     * Busca uma promoção pelo ID
     */
    public static function get_promo_by_id( int $id ) : ?array {
        if ( $id <= 0 ) return null;

        global $wpdb;
        $tbl = self::table_promos();

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $tbl WHERE id = %d LIMIT 1", $id),
            ARRAY_A
        );

        if ( !$row ) return null;

        // Decodifica config_json
        $row['config'] = [];
        if ( !empty($row['config_json']) ) {
            $decoded = json_decode($row['config_json'], true);
            if ( is_array($decoded) ) {
                $row['config'] = $decoded;
            }
        }

        return $row;
    }

    /**
     * Lista todas as promoções
     */
    public static function get_all_promos() : array {
        global $wpdb;
        $tbl = self::table_promos();

        // Verifica se tabela existe
        $table_exists = $wpdb->get_var(
            $wpdb->prepare("SHOW TABLES LIKE %s", $tbl)
        );
        if ( $table_exists !== $tbl ) {
            return [];
        }

        $rows = $wpdb->get_results(
            "SELECT * FROM $tbl ORDER BY created_at DESC",
            ARRAY_A
        );

        if ( !$rows ) return [];

        foreach ( $rows as &$row ) {
            $row['config'] = [];
            if ( !empty($row['config_json']) ) {
                $decoded = json_decode($row['config_json'], true);
                if ( is_array($decoded) ) {
                    $row['config'] = $decoded;
                }
            }
        }

        return $rows;
    }

    /* ============================================================
     * CONFIG (CACHE) - COM SUPORTE A PROMOÇÃO
     * ============================================================ */

    public static function get_config( string $mode, string $platform, string $promo_code = '' ) : array {
        // Se tem cupom válido, busca config do cupom
        if ( !empty($promo_code) ) {
            $promo = self::get_promo_by_code($promo_code);
            if ( $promo && !empty($promo['active']) && !empty($promo['config']) ) {
                $config = $promo['config'];
                // Busca config específica do modo/plataforma
                if ( isset($config[$mode][$platform]) ) {
                    $cfg = $config[$mode][$platform];
                    // Garante valores padrão
                    return self::normalize_config($cfg, $mode);
                }
            }
        }

        // Config padrão (comportamento original)
        $cache_key = "cs_cfg_{$mode}_{$platform}";
        $cached = get_transient($cache_key);
        if ( $cached !== false ) return $cached;

        global $wpdb;
        $tbl = self::table_config();
        $sql = $wpdb->prepare(
            "SELECT * FROM {$tbl} WHERE mode=%s AND platform=%s LIMIT 1",
            $mode, $platform
        );
        $row = $wpdb->get_row($sql, ARRAY_A);

        if ( ! $row ) {
            $row = [
                'mode'                 => $mode,
                'platform'             => $platform,
                'price_100k'           => 0.00,
                'has_50k'              => 0,
                'price_50k'            => 0.00,
                'min_coins'            => 100000,
                'max_coins'            => ($mode === 'lance') ? 2000000 : 50000000,
                'sniper_threshold'     => 10000000,
                'step_below'           => 100000,
                'step_above'           => 1000000,
                'half_100k_csv'        => null,
                'bonus_enabled'        => 0,
                'bonus_per_100k'       => 0,
                'bonus_cond_enabled'   => 0,
                'bonus_cond_threshold' => 0,
                'bonus_cond_per_100k'  => 0,
            ];
        } else {
            $row = self::normalize_config($row, $mode);
        }

        set_transient($cache_key, $row, 60);
        return $row;
    }

    /**
     * Normaliza uma config (garante todos os campos com valores padrão)
     */
    protected static function normalize_config( array $cfg, string $mode ) : array {
        $defaults = [
            'half_100k_csv'        => null,
            'bonus_enabled'        => 0,
            'bonus_per_100k'       => 0,
            'bonus_cond_enabled'   => 0,
            'bonus_cond_threshold' => 0,
            'bonus_cond_per_100k'  => 0,
            'price_100k'           => 0.00,
            'has_50k'              => 0,
            'price_50k'            => 0.00,
            'min_coins'            => 100000,
            'max_coins'            => ($mode === 'lance') ? 2000000 : 50000000,
            'sniper_threshold'     => 10000000,
            'step_below'           => 100000,
            'step_above'           => 1000000,
        ];

        foreach ($defaults as $k => $v) {
            if ( ! array_key_exists($k, $cfg) ) $cfg[$k] = $v;
        }

        // Normaliza flags / valores
        $cfg['has_50k']               = (int)$cfg['has_50k'] > 0 ? 1 : 0;
        $cfg['bonus_enabled']         = (int)$cfg['bonus_enabled'] > 0 ? 1 : 0;
        $cfg['bonus_per_100k']        = isset($cfg['bonus_per_100k']) ? (int)$cfg['bonus_per_100k'] : 0;
        $cfg['bonus_cond_enabled']    = (int)$cfg['bonus_cond_enabled'] > 0 ? 1 : 0;
        $cfg['bonus_cond_threshold']  = isset($cfg['bonus_cond_threshold']) ? (int)$cfg['bonus_cond_threshold'] : 0;
        $cfg['bonus_cond_per_100k']   = isset($cfg['bonus_cond_per_100k']) ? (int)$cfg['bonus_cond_per_100k'] : 0;

        return $cfg;
    }

    public static function clear_config_cache() {
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_cs_cfg_%' OR option_name LIKE '_transient_timeout_cs_cfg_%'");
    }

    /* ============================================================
     * LIMITES / STEPS / VALUES PERMITIDOS
     * ============================================================ */

    /**
     * Lê e normaliza os "quebrados" configurados (CSV) para inteiros (coins).
     */
    protected static function parse_half_100k_csv(array $cfg, int $min, int $max) : array {
        $csv = isset($cfg['half_100k_csv']) ? (string)$cfg['half_100k_csv'] : '';
        if ($csv === '') return [];
        $parts = array_filter(array_map('trim', preg_split('/,/', $csv)));
        $vals  = [];
        foreach ($parts as $p) {
            $n = self::parse_coins($p);
            if ($n > 0 && $n >= $min && $n <= $max) {
                $vals[] = $n;
            }
        }
        $vals = array_values(array_unique($vals));
        sort($vals, SORT_NUMERIC);
        return $vals;
    }

    /**
     * Limites/step por modo (para informação do cliente).
     */
    public static function resolve_limits( string $mode, string $platform, int $coins_current = 0, string $promo_code = '' ) : array {
        $mode = ($mode === 'sniper') ? 'sniper' : 'lance';
        $platform  = in_array($platform, ['ps','xbox','pc'], true) ? $platform : 'ps';

        $cfg = self::get_config($mode, $platform, $promo_code);

        $min = (int) ($cfg['min_coins'] ?: 100000);
        $max = (int) ($cfg['max_coins'] ?: (($mode === 'lance') ? 2000000 : 50000000));

        if ( $mode === 'sniper' ) {
            $threshold  = (int) ($cfg['sniper_threshold'] ?: 10000000);
            $step_below = (int) ($cfg['step_below'] ?: 100000);
            $step_above = (int) ($cfg['step_above'] ?: 1000000);
            $step = ($coins_current >= $threshold) ? $step_above : $step_below;
            return compact('min','max','step','threshold','step_below','step_above');
        }

        // LANCE
        $threshold  = 1000000;
        $step_below = 100000;
        $step_above = 1000000;
        $step = ($coins_current >= $threshold) ? $step_above : $step_below;
        return compact('min','max','step','threshold','step_below','step_above');
    }

    /**
     * Constrói o conjunto de valores permitidos para seleção (padrão ∪ "quebrados").
     */
    protected static function allowed_values(string $mode, string $platform, int $coins_current = 0, string $promo_code = '') : array {
        $mode = ($mode === 'sniper') ? 'sniper' : 'lance';
        $platform  = in_array($platform, ['ps','xbox','pc'], true) ? $platform : 'ps';

        $cfg    = self::get_config($mode, $platform, $promo_code);
        $limits = self::resolve_limits($mode, $platform, $coins_current, $promo_code);

        $min = (int)$limits['min'];
        $max = (int)$limits['max'];
        $threshold = (int)($limits['threshold'] ?? ($mode === 'sniper' ? 10000000 : 1000000));

        $out = [];

        // 50k opcional
        if ((int)$cfg['has_50k'] > 0 && $min <= 50000 && $max >= 50000) {
            $out[] = 50000;
        }

        // Fluxo padrão
        $startBelow = max(100000, $min);
        if ($startBelow % 100000 !== 0) {
            $startBelow = (int)(ceil($startBelow / 100000) * 100000);
        }

        // Até o threshold: 100k em 100k
        for ($v = $startBelow; $v <= min($threshold, $max); $v += 100000) {
            $out[] = $v;
        }

        // Acima do threshold: 1kk em 1kk
        if ($max >= $threshold) {
            $base = max($threshold, 1000000);
            if ($base % 1000000 !== 0) {
                $base = (int)(ceil($base / 1000000) * 1000000);
            }
            for ($v = $base; $v <= $max; $v += 1000000) {
                $out[] = $v;
            }
        }

        // Quebrados: somente em LANCE
        if ($mode === 'lance') {
            $extras = self::parse_half_100k_csv($cfg, $min, $max);
            foreach ($extras as $e) { $out[] = $e; }
        }

        // Garante min/max
        $out[] = $min;
        $out[] = $max;

        // Dedup, ordena e clampa
        $out = array_values(array_unique(array_filter($out, function($n) use ($min,$max){ return $n >= $min && $n <= $max; })));
        sort($out, SORT_NUMERIC);
        return $out;
    }

    /**
     * Fornece somente os "extras" (quebrados) para o REST /limits → inject (modo lance).
     */
    public static function get_injected_values(string $mode, string $platform, int $coins_current = 0, string $promo_code = '') : array {
        $mode = ($mode === 'sniper') ? 'sniper' : 'lance';
        if ($mode !== 'lance') return [];
        $platform  = in_array($platform, ['ps','xbox','pc'], true) ? $platform : 'ps';

        $cfg    = self::get_config($mode, $platform, $promo_code);
        $limits = self::resolve_limits($mode, $platform, $coins_current, $promo_code);
        return self::parse_half_100k_csv($cfg, (int)$limits['min'], (int)$limits['max']);
    }

    /**
     * Ajusta valor ao permitido mais próximo (autoridade do back)
     */
    public static function clamp_to_step( string $mode, string $platform, int $coins, string $promo_code = '' ) : array {
        $mode = ($mode === 'sniper') ? 'sniper' : 'lance';
        $platform  = in_array($platform, ['ps','xbox','pc'], true) ? $platform : 'ps';

        $limits  = self::resolve_limits($mode, $platform, $coins, $promo_code);
        $min     = (int)$limits['min'];
        $max     = (int)$limits['max'];
        $coins   = max($min, min($max, $coins));

        // Snap para o valor permitido mais próximo
        $allowed = self::allowed_values($mode, $platform, $coins, $promo_code);
        if (!empty($allowed)) {
            if (in_array($coins, $allowed, true)) {
                $coins_adj = $coins;
            } else {
                $best = $allowed[0];
                $bestD = abs($coins - $best);
                foreach ($allowed as $val) {
                    $d = abs($coins - $val);
                    if ($d < $bestD) { $bestD = $d; $best = $val; }
                }
                $coins_adj = $best;
            }
        } else {
            $step = (int)$limits['step'];
            $coins_adj = (int) ( round($coins / $step) * $step );
            if ( $coins_adj < $min ) $coins_adj = $min;
            if ( $coins_adj > $max ) $coins_adj = $max;
        }

        $limits['coins'] = (int)$coins_adj;
        return $limits;
    }

    /* ============================================================
     * CÁLCULO DE PREÇO + BÔNUS (COM SUPORTE MULTI-MOEDA)
     * ============================================================ */

    public static function calc( string $mode, string $platform, int $coins, string $promo_code = '' ) : array {
        $mode      = ($mode === 'sniper') ? 'sniper' : 'lance';
        $platform  = in_array($platform, ['ps','xbox','pc'], true) ? $platform : 'ps';
        $cfg       = self::get_config($mode, $platform, $promo_code);

        // Detecta moeda do usuário
        $currency_info = self::detect_user_currency();
        $currency_code = $currency_info['currency_code'];
        $currency_symbol = $currency_info['currency_symbol'];
        $exchange_rate = $currency_info['exchange_rate'];

        $bonus_enabled          = !empty($cfg['bonus_enabled']);
        $bonus_per_100k         = isset($cfg['bonus_per_100k']) ? (int)$cfg['bonus_per_100k'] : 0;
        $bonus_cond_enabled     = !empty($cfg['bonus_cond_enabled']);
        $bonus_cond_threshold   = isset($cfg['bonus_cond_threshold']) ? (int)$cfg['bonus_cond_threshold'] : 0;
        $bonus_cond_per_100k    = isset($cfg['bonus_cond_per_100k']) ? (int)$cfg['bonus_cond_per_100k'] : 0;

        // 50k fixo (não aplicamos bônus por padrão aqui)
        if ( ((int)$cfg['has_50k'] > 0) && $coins === 50000 ) {
            $price_brl    = (float)$cfg['price_50k'];
            $price        = $price_brl * $exchange_rate;
            $bonus_coins  = 0;
            $total_coins  = 50000;

            return [
                'mode'                    => $mode,
                'platform'                => $platform,
                'coins'                   => 50000,
                'is_50k'                  => true,
                'price'                   => $price,
                'price_brl'               => self::format_brl($price_brl),
                'price_formatted'         => self::format_price($price, $currency_code, $currency_symbol),
                'currency_code'           => $currency_code,
                'currency_symbol'         => $currency_symbol,
                'exchange_rate'           => $exchange_rate,
                'step_used'               => 50000,
                'bonus_enabled'           => $bonus_enabled,
                'bonus_per_100k'          => $bonus_per_100k,
                'bonus_cond_enabled'      => $bonus_cond_enabled,
                'bonus_cond_threshold'    => $bonus_cond_threshold,
                'bonus_cond_per_100k'     => $bonus_cond_per_100k,
                'bonus_effective_per_100k'=> 0,
                'bonus_cond_applied'      => false,
                'bonus_coins'             => $bonus_coins,
                'total_coins'             => $total_coins,
                'promo_code'              => $promo_code,
            ];
        }

        $lim    = self::clamp_to_step($mode, $platform, $coins, $promo_code);
        $coins  = (int)$lim['coins'];

        // Preço linear por blocos de 100k (em BRL)
        // Faixas de preço têm prioridade sobre price_100k padrão (somente quando sem promo ativa)
        $blocks = $coins / 100000;
        $price_100k_effective = (float) $cfg['price_100k'];
        if ( empty( $promo_code ) ) {
            $tiered = self::get_price_for_coins( $mode, $platform, $coins );
            if ( $tiered !== null ) {
                $price_100k_effective = $tiered;
            }
        }
        $price_brl = $blocks * $price_100k_effective;

        // Converte para moeda do usuário
        $price = $price_brl * $exchange_rate;

        // Bônus efetivo por 100k
        $bonus_effective_per_100k = $bonus_per_100k;
        $bonus_cond_applied       = false;

        if ($bonus_cond_enabled && $bonus_cond_threshold > 0 && $coins >= $bonus_cond_threshold && $bonus_cond_per_100k > 0) {
            $bonus_effective_per_100k = $bonus_cond_per_100k;
            $bonus_cond_applied       = true;
        }

        $bonus_coins = 0;
        $total_coins = $coins;

        if ( $bonus_enabled && $bonus_effective_per_100k > 0 ) {
            $blocks_int = (int) round($blocks);
            if ( $blocks_int > 0 ) {
                $bonus_coins = $blocks_int * $bonus_effective_per_100k;
                $total_coins = $coins + $bonus_coins;
            }
        }

        return [
            'mode'                    => $mode,
            'platform'                => $platform,
            'coins'                   => $coins,
            'is_50k'                  => false,
            'price'                   => $price,
            'price_brl'               => self::format_brl($price_brl),
            'price_formatted'         => self::format_price($price, $currency_code, $currency_symbol),
            'currency_code'           => $currency_code,
            'currency_symbol'         => $currency_symbol,
            'exchange_rate'           => $exchange_rate,
            'step_used'               => (int)($lim['step'] ?? 100000),
            'limits'                  => $lim,
            'bonus_enabled'           => $bonus_enabled,
            'bonus_per_100k'          => $bonus_per_100k,
            'bonus_cond_enabled'      => $bonus_cond_enabled,
            'bonus_cond_threshold'    => $bonus_cond_threshold,
            'bonus_cond_per_100k'     => $bonus_cond_per_100k,
            'bonus_effective_per_100k'=> $bonus_effective_per_100k,
            'bonus_cond_applied'      => $bonus_cond_applied,
            'bonus_coins'             => $bonus_coins,
            'total_coins'             => $total_coins,
            'promo_code'              => $promo_code,
        ];
    }

    /* ============================================================
     * WOO — PRODUTO DINÂMICO / PREÇO DINÂMICO / CHECKOUT (BUY NOW)
     * Mantido para retrocompatibilidade — não é mais chamado pelo finalize.
     * ============================================================ */

    public static function ensure_product_id() : int {
        $product_id = (int) get_option('cs_dynamic_product_id', 0);

        if ( $product_id && get_post_status($product_id) ) {
            wp_update_post([
                'ID'           => $product_id,
                'post_content' => '',
                'post_excerpt' => '',
            ]);
            update_post_meta($product_id, '_short_description', '');
            return $product_id;
        }

        $post_id = wp_insert_post([
            'post_title'   => 'FIFA Coins (Dinâmico)',
            'post_status'  => 'publish',
            'post_type'    => 'product',
            'post_content' => '',
            'post_excerpt' => '',
        ]);

        if ( $post_id && ! is_wp_error($post_id) ) {
            update_post_meta($post_id, '_virtual', 'yes');
            update_post_meta($post_id, '_regular_price', '0');
            update_post_meta($post_id, '_price', '0');
            update_post_meta($post_id, '_stock_status', 'instock');
            update_post_meta($post_id, '_manage_stock', 'no');
            update_option('cs_dynamic_product_id', (int)$post_id);
            return (int)$post_id;
        }

        return 0;
    }

    public static function hook_cart_item_price() {
        add_action('woocommerce_before_calculate_totals', function($cart){
            if ( is_admin() && !defined('DOING_AJAX') ) return;
            if ( empty($cart) || ! $cart instanceof WC_Cart ) return;

            foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
                if ( isset($cart_item['cs_price']) ) {
                    $price = (float)$cart_item['cs_price'];
                    if ( isset($cart_item['data']) && is_object($cart_item['data']) && method_exists($cart_item['data'], 'set_price') ) {
                        $cart_item['data']->set_price( $price );
                    }
                }
            }
        }, 1);
    }

    /**
     * Mantido para retrocompatibilidade.
     * Não é mais usado pelo fluxo principal de finalização.
     */
    public static function add_to_cart_and_checkout( array $data ) : array {
        if ( ! class_exists('WooCommerce') ) {
            return ['error' => 'WooCommerce não está ativo.'];
        }

        if ( function_exists('wc_load_cart') ) {
            wc_load_cart();
        }

        if ( ! function_exists('WC') || ! WC()->cart ) {
            return ['error' => 'Carrinho indisponível no momento. Tente atualizar a página e finalizar novamente.'];
        }

        self::hook_cart_item_price();

        $mode       = 'lance';
        $platform   = ($data['platform'] ?? 'ps');
        $platform   = in_array($platform, ['ps','xbox','pc'], true) ? $platform : 'ps';
        $coins      = (int) ($data['coins'] ?? 0);
        $promo_code = isset($data['promo']) ? sanitize_text_field($data['promo']) : '';

        $calc = self::calc($mode, $platform, $coins, $promo_code);
        if ( empty($calc['coins']) || $calc['coins'] < 50000 ) {
            return ['error' => 'Quantidade inválida.'];
        }

        // Detecta moeda
        $currency_code = isset($calc['currency_code']) ? $calc['currency_code'] : 'BRL';
        $currency_info = self::detect_user_currency();
        $lang = $currency_info['lang'];
        
        // IMPORTANTE: Salva moeda na sessão WC (não em option)
        if ( function_exists('WC') && WC()->session ) {
            WC()->session->set('cs_user_currency', $currency_code);
        }

        $coins_base   = (int)$calc['coins'];
        $bonus_coins  = isset($calc['bonus_coins']) ? (int)$calc['bonus_coins'] : 0;
        $total_coins  = isset($calc['total_coins']) ? (int)$calc['total_coins'] : $coins_base;

        $label_base  = self::format_coins_label($coins_base);
        $label_bonus = $bonus_coins > 0 ? self::format_coins_label($bonus_coins) : null;
        $label_total = self::format_coins_label($total_coins);

        $coins_label_display = $label_base;
        if ( $bonus_coins > 0 ) {
            $bonus_word = self::translate_text('bonus', $lang);
            $coins_label_display = sprintf('%s + %s %s', $label_base, $label_bonus, $bonus_word);
        }

        $platform_label = [
            'ps'   => 'PlayStation',
            'xbox' => 'Xbox',
            'pc'   => 'PC',
        ][$platform] ?? strtoupper($platform);

        $buy_now_text = self::translate_text('buy_now_mode', $lang);
        $name = sprintf('%s %s', $coins_label_display, $buy_now_text);
        
        // Adiciona indicação de cupom se houver
        if ( !empty($promo_code) ) {
            $coupon_text = self::translate_text('coupon', $lang);
            $name .= sprintf(' (%s: %s)', $coupon_text, $promo_code);
        }

        $for_text = self::translate_text('for_platform', $lang);
        $total_text = self::translate_text('total', $lang);

        if ( $bonus_coins > 0 ) {
            $desc = sprintf(
                '%s (%s %s) %s %s %s',
                $coins_label_display,
                $total_text,
                $label_total,
                $for_text,
                $platform_label,
                $buy_now_text
            );
        } else {
            $desc = sprintf('%s %s %s %s', $label_base, $for_text, $platform_label, $buy_now_text);
        }

        // 1) Registra log e pega token
        $buynow_token = null;
        $log = self::create_buynow_order_log([
            'platform'    => $platform,
            'valor_k'     => $coins_label_display,
            'bonus_coins' => $bonus_coins,
            'total_coins' => $total_coins,
            'price_brl'   => (float)$calc['price'],
            'promo_code'  => $promo_code,
        ]);
        if ( ! empty($log['ok']) && ! empty($log['token']) ) {
            $buynow_token = (string)$log['token'];
        }

        // 2) Produto dinâmico
        $product_id = self::ensure_product_id();
        if ( ! $product_id ) {
            return ['error' => 'Falha ao preparar produto dinâmico.'];
        }

        // 3) Limpa carrinho e adiciona item
        WC()->cart->empty_cart();

        $cart_item_data = [
            'cs_price'        => (float)$calc['price'],
            'cs_mode'         => $mode,
            'cs_platform'     => $platform,
            'cs_coins'        => $coins_base,
            'cs_bonus_coins'  => $bonus_coins,
            'cs_total_coins'  => $total_coins,
            'cs_label'        => $name,
            'cs_desc'         => $desc,
            'cs_promo_code'   => $promo_code,
            'cs_currency'     => $currency_code,
        ];

        if ( ! empty($buynow_token) ) {
            $cart_item_data['cs_buynow_token'] = $buynow_token;
        }

        $item_key = WC()->cart->add_to_cart(
            $product_id,
            1,
            0,
            [],
            $cart_item_data
        );

        if ( ! $item_key ) {
            return ['error' => 'Não foi possível adicionar ao carrinho.'];
        }

        $ci = WC()->cart->get_cart_item($item_key);
        if ( isset($ci['data']) && is_object($ci['data']) && method_exists($ci['data'], 'set_price') ) {
            $ci['data']->set_price( (float)$calc['price'] );
        }

        WC()->cart->calculate_totals();

        $checkout_url = function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : home_url('/checkout/');
        if ( empty($checkout_url) ) {
            return ['error' => 'Não foi possível obter o checkout.'];
        }

        return ['redirect' => $checkout_url];
    }

    /**
     * Registra um log do Buy Now em wp_cs_buynow_orders e retorna token/user/session.
     * Mantido para uso interno / retrocompatibilidade.
     */
    protected static function create_buynow_order_log( array $payload ) : array {
        global $wpdb;

        $tbl = self::table_buynow_orders();
        $token = self::safe_token(12);

        $mode        = 'lance';
        $platform    = isset($payload['platform']) ? (string)$payload['platform'] : 'ps';
        $valor_k     = isset($payload['valor_k']) ? (string)$payload['valor_k'] : '';
        $bonus_coins = isset($payload['bonus_coins']) ? (int)$payload['bonus_coins'] : 0;
        $total_coins = isset($payload['total_coins']) ? (int)$payload['total_coins'] : 0;
        $price_brl   = isset($payload['price_brl']) ? (float)$payload['price_brl'] : 0.0;
        $promo_code  = isset($payload['promo_code']) ? (string)$payload['promo_code'] : '';

        // VALIDAÇÃO: Garante price_brl válido
        if ( ! is_numeric($price_brl) || is_nan($price_brl) || is_infinite($price_brl) || $price_brl < 0 ) {
            $price_brl = 0.0;
        }

        $user_id = function_exists('get_current_user_id') ? (int) get_current_user_id() : 0;

        $session_key = '';
        if ( function_exists('WC') && WC()->session && method_exists(WC()->session, 'get_customer_id') ) {
            $session_key = (string) WC()->session->get_customer_id();
        }

        if ( $session_key === '' && function_exists('wp_get_session_token') ) {
            $session_key = (string) wp_get_session_token();
        }
        if ( $session_key === '' && function_exists('wp_generate_uuid4') ) {
            $session_key = (string) wp_generate_uuid4();
        }
        if ( $session_key === '' ) {
            $session_key = 't_' . (string) time();
        }

        $session_key = substr($session_key, 0, 100);
        $status     = 'pending';
        $created_at = current_time('mysql');

        $ok = $wpdb->insert(
            $tbl,
            [
                'token'       => $token,
                'mode'        => $mode,
                'platform'    => $platform,
                'valor_k'     => $valor_k,
                'price_brl'   => $price_brl,
                'status'      => $status,
                'created_at'  => $created_at,
                'bonus_coins' => $bonus_coins,
                'total_coins' => $total_coins,
                'user_id'     => $user_id,
                'session_key' => $session_key,
                'promo_code'  => $promo_code,
            ],
            ['%s','%s','%s','%s','%f','%s','%s','%d','%d','%d','%s','%s']
        );

        if ( ! $ok ) {
            if ( defined('WP_DEBUG') && WP_DEBUG ) {
                error_log('[Coins Selector] Falha ao inserir em cs_buynow_orders: ' . $wpdb->last_error);
            }
            return ['ok' => false, 'error' => 'db_insert_failed'];
        }

        return [
            'ok'          => true,
            'token'       => $token,
            'user_id'     => $user_id,
            'session_key' => $session_key,
        ];
    }

    /* ============================================================
     * BUY NOW — TOKEN / REDIRECT (NOVO — espelho do Sniper)
     * Grava na tabela wp_cs_buynow_orders e redireciona para
     * a mesma página de formulário do Sniper com ?token=...
     * ============================================================ */

    public static function create_buynow_order( array $data ) : array {
        global $wpdb;

        $mode       = 'lance';
        $platform   = ($data['platform'] ?? 'ps');
        $platform   = in_array($platform, ['ps','xbox','pc'], true) ? $platform : 'ps';
        $coins_in   = (int) ($data['coins'] ?? 0);
        $promo_code = isset($data['promo']) ? sanitize_text_field($data['promo']) : '';

        $calc = self::calc($mode, $platform, $coins_in, $promo_code);
        if ( empty($calc['coins']) || $calc['coins'] < 50000 ) {
            return ['error' => 'Quantidade inválida.'];
        }

        $coins_numeric = (int)$calc['coins'];
        $bonus_coins   = isset($calc['bonus_coins']) ? (int)$calc['bonus_coins'] : 0;
        $total_coins   = isset($calc['total_coins']) ? (int)$calc['total_coins'] : $coins_numeric;
        $price_brl     = isset($calc['price']) ? (float)$calc['price'] : 0.0;

        // VALIDAÇÃO: Garante price_brl válido
        if ( ! is_numeric($price_brl) || is_nan($price_brl) || is_infinite($price_brl) || $price_brl < 0 ) {
            $price_brl = 0.0;
        }

        $base_label  = self::format_coins_label($coins_numeric);
        $bonus_label = $bonus_coins > 0 ? self::format_coins_label($bonus_coins) : null;

        $valor_k = $base_label;
        if ( $bonus_coins > 0 ) {
            $valor_k = sprintf('%s + %s bônus', $base_label, $bonus_label);
        }

        $token = self::safe_token(12);
        $tbl   = self::table_buynow_orders();

        $ok = $wpdb->insert($tbl, [
            'token'       => $token,
            'mode'        => $mode,
            'platform'    => $platform,
            'valor_k'     => $valor_k,
            'bonus_coins' => $bonus_coins,
            'total_coins' => $total_coins,
            'price_brl'   => $price_brl,
            'status'      => 'pending',
            'created_at'  => current_time('mysql'),
            'promo_code'  => $promo_code,
        ], ['%s','%s','%s','%s','%d','%d','%f','%s','%s','%s']);

        if ( ! $ok ) {
            return ['error' => 'Não foi possível registrar o pedido Buy Now.'];
        }

        // Redireciona para a mesma página de formulário do Sniper
        $url = add_query_arg(['token' => $token], self::get_sniper_form_url());
        return ['redirect' => $url, 'token' => $token];
    }

    /* ============================================================
     * SNIPER — TOKEN / REDIRECT
     * ============================================================ */

    public static function get_sniper_form_url() : string {
        if ( defined('CS_SNIPER_FORM_URL') && CS_SNIPER_FORM_URL ) {
            $fixed = esc_url_raw( CS_SNIPER_FORM_URL );
            if ( $fixed ) {
                return apply_filters('cs_sniper_form_url', $fixed);
            }
        }

        $page_id = (int) get_option('cs_sniper_form_page_id', 0);
        if ( $page_id && get_post_status($page_id) ) {
            $url = get_permalink($page_id);
            return apply_filters('cs_sniper_form_url', $url);
        }

        return apply_filters('cs_sniper_form_url', home_url('/') );
    }

    public static function create_sniper_order( array $data ) : array {
        global $wpdb;

        $mode       = 'sniper';
        $platform   = ($data['platform'] ?? 'ps');
        $platform   = in_array($platform, ['ps','xbox','pc'], true) ? $platform : 'ps';
        $coins_in   = (int) ($data['coins'] ?? 0);
        $promo_code = isset($data['promo']) ? sanitize_text_field($data['promo']) : '';

        $calc = self::calc($mode, $platform, $coins_in, $promo_code);
        if ( empty($calc['coins']) || $calc['coins'] < 50000 ) {
            return ['error' => 'Quantidade inválida.'];
        }

        $coins_numeric = (int)$calc['coins'];
        $bonus_coins   = isset($calc['bonus_coins']) ? (int)$calc['bonus_coins'] : 0;
        $total_coins   = isset($calc['total_coins']) ? (int)$calc['total_coins'] : $coins_numeric;
        $price_brl     = isset($calc['price']) ? (float)$calc['price'] : 0.0;

        // VALIDAÇÃO: Garante price_brl válido
        if ( ! is_numeric($price_brl) || is_nan($price_brl) || is_infinite($price_brl) || $price_brl < 0 ) {
            $price_brl = 0.0;
        }

        $base_label  = self::format_coins_label($coins_numeric);
        $bonus_label = $bonus_coins > 0 ? self::format_coins_label($bonus_coins) : null;

        $valor_k = $base_label;
        if ( $bonus_coins > 0 ) {
            $valor_k = sprintf('%s + %s bônus', $base_label, $bonus_label);
        }

        $token = self::safe_token(12);
        $tbl   = self::table_sniper_orders();

        $ok = $wpdb->insert($tbl, [
            'token'       => $token,
            'mode'        => $mode,
            'platform'    => $platform,
            'valor_k'     => $valor_k,
            'bonus_coins' => $bonus_coins,
            'total_coins' => $total_coins,
            'price_brl'   => $price_brl,
            'status'      => 'pending',
            'created_at'  => current_time('mysql'),
            'promo_code'  => $promo_code,
        ], ['%s','%s','%s','%s','%d','%d','%f','%s','%s','%s']);

        if ( ! $ok ) {
            return ['error' => 'Não foi possível registrar o pedido Sniper.'];
        }

        $url = add_query_arg(['token' => $token], self::get_sniper_form_url());
        return ['redirect' => $url, 'token' => $token];
    }
}