<?php
if ( ! defined('ABSPATH') ) exit;

class CS_Rest {

    public static function register() {
        add_action('rest_api_init', function() {
            register_rest_route(CS_NS, '/limits', [
                'methods'  => 'GET',
                'callback' => [__CLASS__, 'limits'],
                'args'     => [
                    'mode'     => ['required' => true],
                    'platform' => ['required' => true],
                    'coins'    => ['required' => false],
                    'promo'    => ['required' => false],
                ],
                'permission_callback' => '__return_true',
            ]);

            register_rest_route(CS_NS, '/calc', [
                'methods'  => 'GET',
                'callback' => [__CLASS__, 'calc'],
                'args'     => [
                    'mode'     => ['required' => true],
                    'platform' => ['required' => true],
                    'coins'    => ['required' => true],
                    'promo'    => ['required' => false],
                ],
                'permission_callback' => '__return_true',
            ]);

            register_rest_route(CS_NS, '/finalize', [
                'methods'  => 'POST',
                'callback' => [__CLASS__, 'finalize'],
                'args'     => [
                    'mode'     => ['required' => true],
                    'platform' => ['required' => true],
                    'coins'    => ['required' => true],
                    'promo'    => ['required' => false],
                ],
                'permission_callback' => function( $req ) {
                    // 1) Nonce WordPress nativo — frontend legado em chamacoins.com.br
                    if ( wp_verify_nonce( $req->get_header('X-WP-Nonce'), 'wp_rest' ) ) {
                        return true;
                    }
                    // 2) API Key — proxy Astro em new.chamacoins.com.br
                    $stored = get_option( 'fgj_api_key', '' );
                    $sent   = trim( (string) ( $req->get_header('X-CS-Api-Key') ?? '' ) );
                    return $stored !== '' && $sent !== '' && hash_equals( $stored, $sent );
                },
            ]);

            register_rest_route(CS_NS, '/validate-promo', [
                'methods'  => 'GET',
                'callback' => [__CLASS__, 'validate_promo'],
                'args'     => [
                    'code' => ['required' => true],
                ],
                'permission_callback' => '__return_true',
            ]);
        });
    }

    public static function limits( WP_REST_Request $req ) {
        $mode       = $req->get_param('mode');
        $platform   = $req->get_param('platform');
        $coins      = CS_Core::parse_coins( $req->get_param('coins') );
        $promo_code = sanitize_text_field( $req->get_param('promo') ?? '' );

        if ( !empty($promo_code) ) {
            $promo = CS_Core::get_promo_by_code($promo_code);
            if ( !$promo || empty($promo['active']) ) {
                $promo_code = '';
            }
        }

        $lim = CS_Core::resolve_limits($mode, $platform, $coins, $promo_code);

        $resp = [
            'mode'       => $mode,
            'platform'   => $platform,
            'min'        => (int)$lim['min'],
            'max'        => (int)$lim['max'],
            'step'       => (int)$lim['step'],
            'threshold'  => isset($lim['threshold']) ? (int)$lim['threshold'] : null,
            'promo'      => $promo_code ?: null,
        ];

        $inject = CS_Core::get_injected_values($mode, $platform, $coins, $promo_code);
        if (!empty($inject)) {
            $resp['inject'] = array_values(array_unique(array_map('intval', $inject)));
        }

        return rest_ensure_response($resp);
    }

    public static function calc( WP_REST_Request $req ) {
        $mode       = $req->get_param('mode');
        $platform   = $req->get_param('platform');
        $coins      = CS_Core::parse_coins( $req->get_param('coins') );
        $promo_code = sanitize_text_field( $req->get_param('promo') ?? '' );

        if ( !empty($promo_code) ) {
            $promo = CS_Core::get_promo_by_code($promo_code);
            if ( !$promo || empty($promo['active']) ) {
                $promo_code = '';
            }
        }

        $calc = CS_Core::calc($mode, $platform, $coins, $promo_code);

        return rest_ensure_response([
            'ok'                       => true,
            'mode'                     => $calc['mode'],
            'platform'                 => $calc['platform'],
            'coins'                    => (int)$calc['coins'],
            'is_50k'                   => (bool)$calc['is_50k'],
            'price'                    => (float)$calc['price'],
            'price_brl'                => $calc['price_brl'],
            'price_formatted'          => $calc['price_formatted'] ?? $calc['price_brl'],
            'currency_code'            => $calc['currency_code'] ?? 'BRL',
            'currency_symbol'          => $calc['currency_symbol'] ?? 'R$',
            'exchange_rate'            => $calc['exchange_rate'] ?? 1.0,
            'step_used'                => (int)$calc['step_used'],
            'limits'                   => $calc['limits'] ?? null,
            'bonus_enabled'            => !empty($calc['bonus_enabled']),
            'bonus_per_100k'           => isset($calc['bonus_per_100k']) ? (int)$calc['bonus_per_100k'] : 0,
            'bonus_cond_enabled'       => !empty($calc['bonus_cond_enabled']),
            'bonus_cond_threshold'     => isset($calc['bonus_cond_threshold']) ? (int)$calc['bonus_cond_threshold'] : 0,
            'bonus_cond_per_100k'      => isset($calc['bonus_cond_per_100k']) ? (int)$calc['bonus_cond_per_100k'] : 0,
            'bonus_effective_per_100k' => isset($calc['bonus_effective_per_100k']) ? (int)$calc['bonus_effective_per_100k'] : (int)($calc['bonus_per_100k'] ?? 0),
            'bonus_cond_applied'       => !empty($calc['bonus_cond_applied']),
            'bonus_coins'              => isset($calc['bonus_coins']) ? (int)$calc['bonus_coins'] : 0,
            'total_coins'              => isset($calc['total_coins']) ? (int)$calc['total_coins'] : (int)$calc['coins'],
            'promo'                    => $promo_code ?: null,
        ]);
    }

    public static function finalize( WP_REST_Request $req ) {
        $mode       = $req->get_param('mode');
        $platform   = $req->get_param('platform');
        $coins      = CS_Core::parse_coins( $req->get_param('coins') );
        $promo_code = sanitize_text_field( $req->get_param('promo') ?? '' );

        if ( !empty($promo_code) ) {
            $promo = CS_Core::get_promo_by_code($promo_code);
            if ( !$promo || empty($promo['active']) ) {
                $promo_code = '';
            }
        }

        if ( $mode === 'sniper' ) {
            $res = CS_Core::create_sniper_order([
                'platform' => $platform,
                'coins'    => $coins,
                'promo'    => $promo_code,
            ]);
        } else {
            $res = CS_Core::create_buynow_order([
                'platform' => $platform,
                'coins'    => $coins,
                'promo'    => $promo_code,
            ]);
        }

        if ( isset($res['error']) ) {
            return new WP_REST_Response(['ok'=>false,'error'=>$res['error']], 400);
        }
        return rest_ensure_response( array_merge(['ok'=>true], $res) );
    }

    public static function validate_promo( WP_REST_Request $req ) {
        $code = sanitize_text_field( $req->get_param('code') ?? '' );

        if ( empty($code) ) {
            return rest_ensure_response([
                'valid' => false,
                'error' => 'Código não informado.',
            ]);
        }

        $promo = CS_Core::get_promo_by_code($code);

        if ( !$promo ) {
            return rest_ensure_response([
                'valid' => false,
                'error' => 'Cupom não encontrado.',
            ]);
        }

        if ( empty($promo['active']) ) {
            return rest_ensure_response([
                'valid' => false,
                'error' => 'Cupom inativo.',
            ]);
        }

        return rest_ensure_response([
            'valid' => true,
            'code'  => $promo['code'],
            'name'  => $promo['name'] ?: $promo['code'],
        ]);
    }
}
CS_Rest::register();