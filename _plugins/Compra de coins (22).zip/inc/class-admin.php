<?php
/**
 * Admin do Coins Selector
 */

if ( ! defined('ABSPATH') ) exit;

class CS_Admin {

    /** ======== Ativação: Tabelas e Seeds ======== */
    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();

        // -------- Tabela de configuração --------
        $tbl_cfg = CS_Core::table_config();
        $sql_cfg = "CREATE TABLE $tbl_cfg (
            id                   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            mode                 VARCHAR(10) NOT NULL,
            platform             VARCHAR(10) NOT NULL,
            price_100k           DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            has_50k              TINYINT(1) NOT NULL DEFAULT 0,
            price_50k            DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            min_coins            INT UNSIGNED NOT NULL DEFAULT 100000,
            max_coins            INT UNSIGNED NOT NULL DEFAULT 50000000,
            sniper_threshold     INT UNSIGNED NOT NULL DEFAULT 10000000,
            step_below           INT UNSIGNED NOT NULL DEFAULT 100000,
            step_above           INT UNSIGNED NOT NULL DEFAULT 1000000,
            half_100k_csv        VARCHAR(255) NULL DEFAULT NULL,
            bonus_enabled        TINYINT(1) NOT NULL DEFAULT 0,
            bonus_per_100k       INT UNSIGNED NOT NULL DEFAULT 0,
            bonus_cond_enabled   TINYINT(1) NOT NULL DEFAULT 0,
            bonus_cond_threshold INT UNSIGNED NOT NULL DEFAULT 0,
            bonus_cond_per_100k  INT UNSIGNED NOT NULL DEFAULT 0,
            updated_at           DATETIME NULL,
            UNIQUE KEY uniq_mode_platform (mode, platform),
            PRIMARY KEY (id)
        ) $charset;";
        dbDelta($sql_cfg);

        // Migrações de coluna (para instalações antigas)
        $col_exists = $wpdb->get_var("SHOW COLUMNS FROM $tbl_cfg LIKE 'half_100k_csv'");
        if ( ! $col_exists ) {
            $wpdb->query("ALTER TABLE $tbl_cfg ADD COLUMN half_100k_csv VARCHAR(255) NULL DEFAULT NULL AFTER step_above");
        }

        $col_bonus_enabled = $wpdb->get_var("SHOW COLUMNS FROM $tbl_cfg LIKE 'bonus_enabled'");
        if ( ! $col_bonus_enabled ) {
            $wpdb->query("ALTER TABLE $tbl_cfg ADD COLUMN bonus_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER half_100k_csv");
        }

        $col_bonus_per = $wpdb->get_var("SHOW COLUMNS FROM $tbl_cfg LIKE 'bonus_per_100k'");
        if ( ! $col_bonus_per ) {
            $wpdb->query("ALTER TABLE $tbl_cfg ADD COLUMN bonus_per_100k INT UNSIGNED NOT NULL DEFAULT 0 AFTER bonus_enabled");
        }

        $col_bonus_cond_enabled = $wpdb->get_var("SHOW COLUMNS FROM $tbl_cfg LIKE 'bonus_cond_enabled'");
        if ( ! $col_bonus_cond_enabled ) {
            $wpdb->query("ALTER TABLE $tbl_cfg ADD COLUMN bonus_cond_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER bonus_per_100k");
        }

        $col_bonus_cond_threshold = $wpdb->get_var("SHOW COLUMNS FROM $tbl_cfg LIKE 'bonus_cond_threshold'");
        if ( ! $col_bonus_cond_threshold ) {
            $wpdb->query("ALTER TABLE $tbl_cfg ADD COLUMN bonus_cond_threshold INT UNSIGNED NOT NULL DEFAULT 0 AFTER bonus_cond_enabled");
        }

        $col_bonus_cond_per = $wpdb->get_var("SHOW COLUMNS FROM $tbl_cfg LIKE 'bonus_cond_per_100k'");
        if ( ! $col_bonus_cond_per ) {
            $wpdb->query("ALTER TABLE $tbl_cfg ADD COLUMN bonus_cond_per_100k INT UNSIGNED NOT NULL DEFAULT 0 AFTER bonus_cond_threshold");
        }

        // -------- Tabela de pedidos Sniper --------
        $tbl_sniper = CS_Core::table_sniper_orders();
        $sql_sniper = "CREATE TABLE $tbl_sniper (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            token       VARCHAR(64) NOT NULL UNIQUE,
            mode        VARCHAR(10) NOT NULL DEFAULT 'sniper',
            platform    VARCHAR(10) NOT NULL,
            coins       VARCHAR(16) NULL,
            valor_k     TEXT NULL,
            bonus_coins INT UNSIGNED NOT NULL DEFAULT 0,
            total_coins INT UNSIGNED NOT NULL DEFAULT 0,
            price_brl   DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            status      VARCHAR(20) NOT NULL DEFAULT 'pending',
            promo_code  VARCHAR(50) NULL DEFAULT NULL,
            created_at  DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) $charset;";
        dbDelta($sql_sniper);

        /* Migração: garante a coluna 'valor_k' */
        $col_valor_k = $wpdb->get_var("SHOW COLUMNS FROM $tbl_sniper LIKE 'valor_k'");
        if ( ! $col_valor_k ) {
            $wpdb->query("ALTER TABLE $tbl_sniper ADD COLUMN valor_k TEXT NULL AFTER coins");
        }

        /* Migração: garante colunas de bônus no sniper */
        $col_sniper_bonus = $wpdb->get_var("SHOW COLUMNS FROM $tbl_sniper LIKE 'bonus_coins'");
        if ( ! $col_sniper_bonus ) {
            $wpdb->query("ALTER TABLE $tbl_sniper ADD COLUMN bonus_coins INT UNSIGNED NOT NULL DEFAULT 0 AFTER valor_k");
        }

        $col_sniper_total = $wpdb->get_var("SHOW COLUMNS FROM $tbl_sniper LIKE 'total_coins'");
        if ( ! $col_sniper_total ) {
            $wpdb->query("ALTER TABLE $tbl_sniper ADD COLUMN total_coins INT UNSIGNED NOT NULL DEFAULT 0 AFTER bonus_coins");
        }

        /* Migração: coluna promo_code no sniper */
        $col_sniper_promo = $wpdb->get_var("SHOW COLUMNS FROM $tbl_sniper LIKE 'promo_code'");
        if ( ! $col_sniper_promo ) {
            $wpdb->query("ALTER TABLE $tbl_sniper ADD COLUMN promo_code VARCHAR(50) NULL DEFAULT NULL AFTER status");
        }

        /* Se 'coins' ainda for INT, converte para VARCHAR(16) */
        $col_coins = $wpdb->get_row("SHOW COLUMNS FROM $tbl_sniper LIKE 'coins'", ARRAY_A);
        if ( $col_coins && isset($col_coins['Type']) && stripos($col_coins['Type'], 'int') !== false ) {
            $wpdb->query("ALTER TABLE $tbl_sniper MODIFY coins VARCHAR(16) NULL");
        }

        // -------- Tabela de pedidos Buy Now --------
        $tbl_buynow = CS_Core::table_buynow_orders();
        $sql_buynow = "CREATE TABLE $tbl_buynow (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            token       VARCHAR(64) NOT NULL UNIQUE,
            mode        VARCHAR(10) NOT NULL DEFAULT 'lance',
            platform    VARCHAR(10) NOT NULL,
            coins       VARCHAR(16) NULL,
            valor_k     TEXT NULL,
            bonus_coins INT UNSIGNED NOT NULL DEFAULT 0,
            total_coins INT UNSIGNED NOT NULL DEFAULT 0,
            price_brl   DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            status      VARCHAR(20) NOT NULL DEFAULT 'pending',
            promo_code  VARCHAR(50) NULL DEFAULT NULL,
            user_id     BIGINT UNSIGNED NOT NULL DEFAULT 0,
            session_key VARCHAR(255) NULL DEFAULT NULL,
            created_at  DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) $charset;";
        dbDelta($sql_buynow);

        /* Migração: coluna promo_code no buynow */
        $col_buynow_promo = $wpdb->get_var("SHOW COLUMNS FROM $tbl_buynow LIKE 'promo_code'");
        if ( ! $col_buynow_promo ) {
            $wpdb->query("ALTER TABLE $tbl_buynow ADD COLUMN promo_code VARCHAR(50) NULL DEFAULT NULL AFTER status");
        }

        // -------- Tabela de agendamentos de configuração --------
        $tbl_sched = CS_Core::table_schedules();
        $sql_sched = "CREATE TABLE $tbl_sched (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            run_at     DATETIME NOT NULL,
            status     VARCHAR(20) NOT NULL DEFAULT 'pending',
            payload    LONGTEXT NOT NULL,
            created_at DATETIME NOT NULL,
            ran_at     DATETIME NULL,
            PRIMARY KEY (id),
            KEY run_at_status (run_at, status)
        ) $charset;";
        dbDelta($sql_sched);

        // -------- Tabela de promoções/cupons --------
        $tbl_promos = CS_Core::table_promos();
        $sql_promos = "CREATE TABLE $tbl_promos (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            code        VARCHAR(50) NOT NULL UNIQUE,
            name        VARCHAR(100) NOT NULL DEFAULT '',
            active      TINYINT(1) NOT NULL DEFAULT 1,
            config_json LONGTEXT NOT NULL,
            expires_at  DATETIME NULL DEFAULT NULL,
            created_at  DATETIME NOT NULL,
            updated_at  DATETIME NULL DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_code (code)
        ) $charset;";
        dbDelta($sql_promos);

        // -------- Tabela de faixas de preço --------
        $tbl_tiers = CS_Core::table_price_tiers();
        $sql_tiers = "CREATE TABLE $tbl_tiers (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            mode        VARCHAR(10) NOT NULL,
            platform    VARCHAR(10) NOT NULL,
            coins_min   BIGINT UNSIGNED NOT NULL DEFAULT 0,
            coins_max   BIGINT UNSIGNED NULL DEFAULT NULL,
            price_100k  DECIMAL(10,4) NOT NULL DEFAULT 0.0000,
            PRIMARY KEY (id),
            KEY idx_mode_platform (mode, platform)
        ) $charset;";
        dbDelta($sql_tiers);

        // Semeia linhas padrão de configuração
        $pairs = [];
        foreach (['lance','sniper'] as $mode) {
            foreach (['ps','xbox','pc'] as $pf) {
                $pairs[] = [$mode, $pf];
            }
        }
        foreach ($pairs as $p) {
            [$mode, $platform] = $p;
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM $tbl_cfg WHERE mode=%s AND platform=%s",
                $mode, $platform
            ));
            if ( ! $exists ) {
                $defaults = [
                    'mode'                 => $mode,
                    'platform'             => $platform,
                    'price_100k'           => 0.00,
                    'has_50k'              => 0,
                    'price_50k'            => 0.00,
                    'min_coins'            => 100000,
                    'max_coins'            => ($mode === 'lance') ? 2000000 : 50000000,
                    'sniper_threshold'     => 10000000,
                    'step_below'           => 100000,
                    'step_above'           => 1000000,
                    'half_100k_csv'        => null,
                    'bonus_enabled'        => 0,
                    'bonus_per_100k'       => 0,
                    'bonus_cond_enabled'   => 0,
                    'bonus_cond_threshold' => 0,
                    'bonus_cond_per_100k'  => 0,
                    'updated_at'           => current_time('mysql'),
                ];
                $wpdb->insert(
                    $tbl_cfg,
                    $defaults,
                    ['%s','%s','%f','%d','%f','%d','%d','%d','%d','%d','%s','%d','%d','%d','%d','%d','%s']
                );
            }
        }

        // Página do formulário Sniper
        if ( ! get_option('cs_sniper_form_page_id') ) {
            add_option('cs_sniper_form_page_id', 0);
        }

        // Normaliza has_50k na base
        $wpdb->query("UPDATE $tbl_cfg SET has_50k = CASE WHEN has_50k > 0 THEN 1 ELSE 0 END");

        CS_Core::clear_config_cache();
    }

    /** ======== Boot no admin ======== */
    public static function boot() {
        add_action('admin_init', [__CLASS__, 'maybe_migrate_schema'], 0);

        add_action('admin_menu', [__CLASS__,'menu']);
        add_action('admin_init', [__CLASS__,'handle_save']);
        add_action('admin_init', [__CLASS__,'handle_save_tiers']);
        add_action('admin_init', [__CLASS__,'handle_schedule']);
        add_action('admin_init', [__CLASS__,'handle_cancel_schedule']);

        // Handlers de promoções
        add_action('admin_init', [__CLASS__,'handle_promo_save']);
        add_action('admin_init', [__CLASS__,'handle_promo_delete']);
        add_action('admin_init', [__CLASS__,'handle_promo_toggle']);

        // Normaliza has_50k
        add_action('admin_init', function() {
            if ( get_option('cs_has50k_normalized') ) return;
            global $wpdb;
            $tbl_cfg = CS_Core::table_config();
            $wpdb->query("UPDATE $tbl_cfg SET has_50k = CASE WHEN has_50k > 0 THEN 1 ELSE 0 END");
            update_option('cs_has50k_normalized', 1);
            CS_Core::clear_config_cache();
        }, 1);
    }

    /**
     * Migração leve que roda em toda página do admin
     */
    public static function maybe_migrate_schema() {
        global $wpdb;
        $tbl_cfg = CS_Core::table_config();

        $table_exists = $wpdb->get_var(
            $wpdb->prepare("SHOW TABLES LIKE %s", $tbl_cfg)
        );
        if ( $table_exists !== $tbl_cfg ) {
            return;
        }

        $ensure_column = function( $column, $definition ) use ( $wpdb, $tbl_cfg ) {
            $exists = $wpdb->get_var(
                $wpdb->prepare("SHOW COLUMNS FROM {$tbl_cfg} LIKE %s", $column)
            );
            if ( ! $exists ) {
                $wpdb->query("ALTER TABLE {$tbl_cfg} ADD COLUMN {$column} {$definition}");
            }
        };

        $ensure_column('half_100k_csv',        "VARCHAR(255) NULL DEFAULT NULL");
        $ensure_column('bonus_enabled',        "TINYINT(1) NOT NULL DEFAULT 0");
        $ensure_column('bonus_per_100k',       "INT UNSIGNED NOT NULL DEFAULT 0");
        $ensure_column('bonus_cond_enabled',   "TINYINT(1) NOT NULL DEFAULT 0");
        $ensure_column('bonus_cond_threshold', "INT UNSIGNED NOT NULL DEFAULT 0");
        $ensure_column('bonus_cond_per_100k',  "INT UNSIGNED NOT NULL DEFAULT 0");

        // Garante tabela de faixas de preço
        $tbl_tiers = CS_Core::table_price_tiers();
        $tiers_exists = $wpdb->get_var(
            $wpdb->prepare( "SHOW TABLES LIKE %s", $tbl_tiers )
        );
        if ( $tiers_exists !== $tbl_tiers ) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            $charset = $wpdb->get_charset_collate();
            $sql_tiers = "CREATE TABLE $tbl_tiers (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                mode        VARCHAR(10) NOT NULL,
                platform    VARCHAR(10) NOT NULL,
                coins_min   BIGINT UNSIGNED NOT NULL DEFAULT 0,
                coins_max   BIGINT UNSIGNED NULL DEFAULT NULL,
                price_100k  DECIMAL(10,4) NOT NULL DEFAULT 0.0000,
                PRIMARY KEY (id),
                KEY idx_mode_platform (mode, platform)
            ) $charset;";
            dbDelta($sql_tiers);
        }

        // Garante tabela de promoções
        $tbl_promos = CS_Core::table_promos();
        $promo_exists = $wpdb->get_var(
            $wpdb->prepare("SHOW TABLES LIKE %s", $tbl_promos)
        );
        if ( $promo_exists !== $tbl_promos ) {
            // Cria a tabela se não existir
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            $charset = $wpdb->get_charset_collate();
            $sql_promos = "CREATE TABLE $tbl_promos (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                code        VARCHAR(50) NOT NULL UNIQUE,
                name        VARCHAR(100) NOT NULL DEFAULT '',
                active      TINYINT(1) NOT NULL DEFAULT 1,
                config_json LONGTEXT NOT NULL,
                expires_at  DATETIME NULL DEFAULT NULL,
                created_at  DATETIME NOT NULL,
                updated_at  DATETIME NULL DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_code (code)
            ) $charset;";
            dbDelta($sql_promos);
        }
    }

    public static function menu() {
        add_menu_page(
            'Coins Selector',
            'Coins Selector',
            'manage_options',
            'coins-selector',
            [__CLASS__,'render_page'],
            'dashicons-money-alt',
            57
        );

        add_submenu_page(
            'coins-selector',
            'Configurações',
            'Configurações',
            'manage_options',
            'coins-selector',
            [__CLASS__,'render_page']
        );

        add_submenu_page(
            'coins-selector',
            'Promoções',
            'Promoções',
            'manage_options',
            'coins-selector-promos',
            [__CLASS__,'render_promos_page']
        );
    }

    /** ======== SALVAR IMEDIATO ======== */
    public static function handle_save() {
        if ( ! isset($_POST['cs_admin_save']) ) return;
        if ( ! current_user_can('manage_options') ) return;
        check_admin_referer('cs_admin');

        $posted = isset($_POST['cs_config']) && is_array($_POST['cs_config'])
            ? $_POST['cs_config']
            : [];

        self::apply_config_array( $posted );

        $posted_tiers = isset($_POST['cs_tiers']) && is_array($_POST['cs_tiers'])
            ? $_POST['cs_tiers']
            : [];
        self::save_tiers( $posted_tiers );

        $page_id = isset($_POST['cs_sniper_form_page_id']) ? (int) $_POST['cs_sniper_form_page_id'] : 0;
        update_option('cs_sniper_form_page_id', $page_id);

        wp_redirect( add_query_arg([
            'page'    => 'coins-selector',
            'updated' => '1',
        ], admin_url('admin.php')) );
        exit;
    }

    /**
     * Aplica um array de configuração diretamente na tabela cs_config.
     */
    public static function apply_config_array( array $posted ) {
        global $wpdb;
        $tbl = CS_Core::table_config();

        foreach ($posted as $mode_key => $rows) {
            if ( ! is_array($rows) ) continue;

            foreach ($rows as $platform_key => $data) {
                $mode     = sanitize_text_field($mode_key);
                $platform = sanitize_text_field($platform_key);

                $price_100k       = isset($data['price_100k']) ? (float) str_replace(',', '.', $data['price_100k']) : 0;
                $has_50k          = !empty($data['has_50k']) ? 1 : 0;
                $price_50k        = isset($data['price_50k']) ? (float) str_replace(',', '.', $data['price_50k']) : 0;
                $min_coins        = isset($data['min_coins']) ? (int) $data['min_coins'] : 100000;
                $max_coins        = isset($data['max_coins']) ? (int) $data['max_coins'] : 2000000;
                $sniper_threshold = isset($data['sniper_threshold']) ? (int) $data['sniper_threshold'] : 10000000;
                $step_below       = isset($data['step_below']) ? (int) $data['step_below'] : 100000;
                $step_above       = isset($data['step_above']) ? (int) $data['step_above'] : 1000000;

                $bonus_enabled    = !empty($data['bonus_enabled']) ? 1 : 0;
                $bonus_per_100k   = isset($data['bonus_per_100k']) ? (int)$data['bonus_per_100k'] : 0;
                if ($bonus_per_100k < 0) $bonus_per_100k = 0;

                $bonus_cond_enabled   = !empty($data['bonus_cond_enabled']) ? 1 : 0;
                $bonus_cond_threshold = 0;
                if ( isset($data['bonus_cond_threshold']) && $data['bonus_cond_threshold'] !== '' ) {
                    $bonus_cond_threshold = CS_Core::parse_coins($data['bonus_cond_threshold']);
                    if ($bonus_cond_threshold < 0) $bonus_cond_threshold = 0;
                }
                $bonus_cond_per_100k = isset($data['bonus_cond_per_100k']) ? (int)$data['bonus_cond_per_100k'] : 0;
                if ($bonus_cond_per_100k < 0) $bonus_cond_per_100k = 0;

                $half_100k_csv = null;
                if ($mode === 'lance') {
                    $raw = isset($data['half_100k_csv']) ? (string)$data['half_100k_csv'] : '';
                    $raw = str_replace([';', '  '], [',', ' '], $raw);
                    $raw = preg_replace('/\s*,\s*/', ',', trim($raw));
                    $half_100k_csv = $raw !== '' ? $raw : null;
                }

                $exists = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM $tbl WHERE mode=%s AND platform=%s",
                    $mode, $platform
                ) );

                $data_upd = [
                    'price_100k'           => $price_100k,
                    'has_50k'              => $has_50k,
                    'price_50k'            => $price_50k,
                    'min_coins'            => $min_coins,
                    'max_coins'            => $max_coins,
                    'sniper_threshold'     => $sniper_threshold,
                    'step_below'           => $step_below,
                    'step_above'           => $step_above,
                    'half_100k_csv'        => $half_100k_csv,
                    'bonus_enabled'        => $bonus_enabled,
                    'bonus_per_100k'       => $bonus_per_100k,
                    'bonus_cond_enabled'   => $bonus_cond_enabled,
                    'bonus_cond_threshold' => $bonus_cond_threshold,
                    'bonus_cond_per_100k'  => $bonus_cond_per_100k,
                    'updated_at'           => current_time('mysql'),
                ];

                if ( $exists ) {
                    $wpdb->update($tbl, $data_upd, ['id' => (int)$exists]);
                } else {
                    $wpdb->insert($tbl, array_merge([
                        'mode'     => $mode,
                        'platform' => $platform,
                    ], $data_upd));
                }
            }
        }

        CS_Core::clear_config_cache();
    }

    /** ======== SALVAR FAIXAS DE PREÇO ======== */
    public static function handle_save_tiers() {
        if ( ! isset($_POST['cs_admin_save']) ) return;
        if ( ! current_user_can('manage_options') ) return;
        // Nonce já verificado no handle_save; aqui só processamos os dados de faixas.
        // handle_save redireciona antes de chegar aqui, portanto este handler
        // é chamado na mesma requisição via admin_init (antes do redirect).
        // Na prática o redirect do handle_save encerra a execução antes de chegarmos
        // aqui, então salvamos as faixas ANTES do redirect adicionando a lógica
        // diretamente no fluxo handle_save. Este método serve de entry-point seguro.
        check_admin_referer('cs_admin');

        $posted = isset($_POST['cs_tiers']) && is_array($_POST['cs_tiers'])
            ? $_POST['cs_tiers']
            : [];

        self::save_tiers($posted);
    }

    /**
     * Persiste as faixas de preço: apaga as existentes para cada mode/platform
     * e re-insere as enviadas via POST.
     */
    public static function save_tiers( array $posted ) {
        global $wpdb;
        $tbl = CS_Core::table_price_tiers();

        $table_exists = $wpdb->get_var(
            $wpdb->prepare( "SHOW TABLES LIKE %s", $tbl )
        );
        if ( $table_exists !== $tbl ) {
            return;
        }

        foreach ( $posted as $mode_key => $platforms ) {
            if ( ! is_array($platforms) ) continue;

            foreach ( $platforms as $platform_key => $tiers ) {
                $mode     = sanitize_text_field($mode_key);
                $platform = sanitize_text_field($platform_key);

                // Remove todas as faixas existentes para este mode/platform
                $wpdb->delete( $tbl, [ 'mode' => $mode, 'platform' => $platform ], [ '%s', '%s' ] );

                if ( ! is_array($tiers) ) continue;

                foreach ( $tiers as $tier ) {
                    $coins_min  = isset($tier['coins_min']) ? (int) $tier['coins_min'] : 0;
                    $coins_max_raw = isset($tier['coins_max']) ? trim( (string) $tier['coins_max'] ) : '';
                    $coins_max  = ( $coins_max_raw !== '' && (int) $coins_max_raw > 0 )
                                    ? (int) $coins_max_raw
                                    : null;
                    $price_100k = isset($tier['price_100k'])
                                    ? (float) str_replace(',', '.', $tier['price_100k'])
                                    : 0.0;

                    if ( $coins_min <= 0 || $price_100k <= 0 ) continue;

                    $wpdb->insert(
                        $tbl,
                        [
                            'mode'      => $mode,
                            'platform'  => $platform,
                            'coins_min' => $coins_min,
                            'coins_max' => $coins_max,
                            'price_100k'=> $price_100k,
                        ],
                        [ '%s', '%s', '%d', '%s', '%f' ]
                    );
                }
            }
        }
    }

    /** ======== AGENDAR MUDANÇA ======== */
    public static function handle_schedule() {
        if ( ! isset($_POST['cs_admin_schedule']) ) return;
        if ( ! current_user_can('manage_options') ) return;
        check_admin_referer('cs_admin');

        $posted = isset($_POST['cs_config']) && is_array($_POST['cs_config'])
            ? $_POST['cs_config']
            : [];

        $date = isset($_POST['cs_schedule_date']) ? sanitize_text_field($_POST['cs_schedule_date']) : '';
        $time = isset($_POST['cs_schedule_time']) ? sanitize_text_field($_POST['cs_schedule_time']) : '';

        if ( empty($date) || empty($time) ) {
            wp_redirect( add_query_arg([
                'page'            => 'coins-selector',
                'cs_sched_error'  => '1',
            ], admin_url('admin.php')) );
            exit;
        }

        try {
            $dt = new DateTime( $date . ' ' . $time, wp_timezone() );
        } catch ( Exception $e ) {
            wp_redirect( add_query_arg([
                'page'            => 'coins-selector',
                'cs_sched_error'  => '1',
            ], admin_url('admin.php')) );
            exit;
        }

        $timestamp = $dt->getTimestamp();
        if ( $timestamp <= time() + 60 ) {
            wp_redirect( add_query_arg([
                'page'            => 'coins-selector',
                'cs_sched_error'  => '1',
            ], admin_url('admin.php')) );
            exit;
        }

        global $wpdb;
        $tbl_sched = CS_Core::table_schedules();

        $payload = [
            'config' => $posted,
        ];
        $json_payload = wp_json_encode( $payload );

        $run_at_gmt = gmdate('Y-m-d H:i:s', $timestamp);

        $ok = $wpdb->insert(
            $tbl_sched,
            [
                'run_at'     => $run_at_gmt,
                'status'     => 'pending',
                'payload'    => $json_payload,
                'created_at' => current_time('mysql'),
                'ran_at'     => null,
            ],
            ['%s','%s','%s','%s','%s']
        );

        if ( ! $ok ) {
            wp_redirect( add_query_arg([
                'page'            => 'coins-selector',
                'cs_sched_error'  => '1',
            ], admin_url('admin.php')) );
            exit;
        }

        $schedule_id = (int) $wpdb->insert_id;

        wp_schedule_single_event( $timestamp, 'cs_apply_scheduled_config', [ $schedule_id ] );

        wp_redirect( add_query_arg([
            'page'     => 'coins-selector',
            'cs_sched' => '1',
        ], admin_url('admin.php')) );
        exit;
    }

    /** ======== CANCELAR AGENDAMENTO ======== */
    public static function handle_cancel_schedule() {
        if ( ! isset($_GET['cs_cancel_schedule']) ) return;
        if ( ! current_user_can('manage_options') ) return;

        $id = (int) $_GET['cs_cancel_schedule'];
        if ( $id <= 0 ) return;

        check_admin_referer('cs_cancel_schedule_' . $id);

        global $wpdb;
        $tbl_sched = CS_Core::table_schedules();

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $tbl_sched WHERE id=%d",
            $id
        ), ARRAY_A );

        if ( ! $row ) {
            wp_redirect( add_query_arg([
                'page'               => 'coins-selector',
                'cs_sched_cancelled' => '1',
            ], admin_url('admin.php')) );
            exit;
        }

        $wpdb->update(
            $tbl_sched,
            [
                'status' => 'cancelled',
                'ran_at' => current_time('mysql'),
            ],
            [ 'id' => $id ],
            ['%s','%s'],
            ['%d']
        );

        $next = wp_next_scheduled('cs_apply_scheduled_config', [ $id ]);
        while ( $next ) {
            wp_unschedule_event( $next, 'cs_apply_scheduled_config', [ $id ] );
            $next = wp_next_scheduled('cs_apply_scheduled_config', [ $id ]);
        }

        wp_redirect( add_query_arg([
            'page'               => 'coins-selector',
            'cs_sched_cancelled' => '1',
        ], admin_url('admin.php')) );
        exit;
    }

    /** ======== CRON: aplica snapshot agendado ======== */
    public static function cron_apply_scheduled_config( $schedule_id ) {
        $schedule_id = (int) $schedule_id;
        if ( $schedule_id <= 0 ) {
            return;
        }

        global $wpdb;
        $tbl_sched = CS_Core::table_schedules();

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $tbl_sched WHERE id=%d",
            $schedule_id
        ), ARRAY_A );

        if ( ! $row ) {
            return;
        }

        if ( $row['status'] !== 'pending' ) {
            return;
        }

        $payload = json_decode( $row['payload'], true );
        if ( ! is_array($payload) || ! isset($payload['config']) || ! is_array($payload['config']) ) {
            $wpdb->update(
                $tbl_sched,
                [
                    'status' => 'error',
                    'ran_at' => current_time('mysql'),
                ],
                [ 'id' => $schedule_id ],
                ['%s','%s'],
                ['%d']
            );
            return;
        }

        self::apply_config_array( $payload['config'] );

        $wpdb->update(
            $tbl_sched,
            [
                'status' => 'done',
                'ran_at' => current_time('mysql'),
            ],
            [ 'id' => $schedule_id ],
            ['%s','%s'],
            ['%d']
        );
    }

    /** ======== Helper: busca agendamentos pendentes ======== */
    protected static function get_pending_schedules() : array {
        global $wpdb;
        $tbl_sched = CS_Core::table_schedules();

        $rows = $wpdb->get_results(
            "SELECT * FROM $tbl_sched WHERE status='pending' ORDER BY run_at ASC LIMIT 50",
            ARRAY_A
        );

        return $rows ? $rows : [];
    }

    /* ================================================================
     * PROMOÇÕES - HANDLERS
     * ================================================================ */

    /** Salvar/Criar promoção */
    public static function handle_promo_save() {
        if ( ! isset($_POST['cs_promo_save']) ) return;
        if ( ! current_user_can('manage_options') ) return;
        check_admin_referer('cs_promo_admin');

        global $wpdb;
        $tbl = CS_Core::table_promos();

        $promo_id   = isset($_POST['promo_id']) ? (int)$_POST['promo_id'] : 0;
        $code       = isset($_POST['promo_code']) ? sanitize_text_field($_POST['promo_code']) : '';
        $name       = isset($_POST['promo_name']) ? sanitize_text_field($_POST['promo_name']) : '';
        $active     = !empty($_POST['promo_active']) ? 1 : 0;
        $expires_at = isset($_POST['promo_expires']) ? sanitize_text_field($_POST['promo_expires']) : '';

        // Valida código
        $code = strtoupper(preg_replace('/[^a-zA-Z0-9_-]/', '', $code));
        if ( empty($code) ) {
            wp_redirect( add_query_arg([
                'page'        => 'coins-selector-promos',
                'promo_error' => 'code_empty',
            ], admin_url('admin.php')) );
            exit;
        }

        // Verifica duplicidade
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $tbl WHERE code = %s AND id != %d",
            $code, $promo_id
        ));
        if ( $existing ) {
            wp_redirect( add_query_arg([
                'page'        => 'coins-selector-promos',
                'promo_error' => 'code_exists',
            ], admin_url('admin.php')) );
            exit;
        }

        // Monta config_json a partir do POST
        $config = [];
        $posted = isset($_POST['promo_config']) && is_array($_POST['promo_config']) 
            ? $_POST['promo_config'] 
            : [];

        foreach ($posted as $mode_key => $platforms) {
            if ( !is_array($platforms) ) continue;
            foreach ($platforms as $platform_key => $data) {
                $mode     = sanitize_text_field($mode_key);
                $platform = sanitize_text_field($platform_key);

                $cfg = [
                    'price_100k'           => isset($data['price_100k']) ? (float)str_replace(',', '.', $data['price_100k']) : 0,
                    'has_50k'              => !empty($data['has_50k']) ? 1 : 0,
                    'price_50k'            => isset($data['price_50k']) ? (float)str_replace(',', '.', $data['price_50k']) : 0,
                    'min_coins'            => isset($data['min_coins']) ? (int)$data['min_coins'] : 100000,
                    'max_coins'            => isset($data['max_coins']) ? (int)$data['max_coins'] : (($mode === 'lance') ? 2000000 : 50000000),
                    'sniper_threshold'     => isset($data['sniper_threshold']) ? (int)$data['sniper_threshold'] : 10000000,
                    'step_below'           => isset($data['step_below']) ? (int)$data['step_below'] : 100000,
                    'step_above'           => isset($data['step_above']) ? (int)$data['step_above'] : 1000000,
                    'half_100k_csv'        => null,
                    'bonus_enabled'        => !empty($data['bonus_enabled']) ? 1 : 0,
                    'bonus_per_100k'       => max(0, isset($data['bonus_per_100k']) ? (int)$data['bonus_per_100k'] : 0),
                    'bonus_cond_enabled'   => !empty($data['bonus_cond_enabled']) ? 1 : 0,
                    'bonus_cond_threshold' => 0,
                    'bonus_cond_per_100k'  => max(0, isset($data['bonus_cond_per_100k']) ? (int)$data['bonus_cond_per_100k'] : 0),
                ];

                if ( isset($data['bonus_cond_threshold']) && $data['bonus_cond_threshold'] !== '' ) {
                    $cfg['bonus_cond_threshold'] = max(0, CS_Core::parse_coins($data['bonus_cond_threshold']));
                }

                if ($mode === 'lance' && isset($data['half_100k_csv'])) {
                    $raw = str_replace([';', '  '], [',', ' '], (string)$data['half_100k_csv']);
                    $raw = preg_replace('/\s*,\s*/', ',', trim($raw));
                    $cfg['half_100k_csv'] = $raw !== '' ? $raw : null;
                }

                if ( !isset($config[$mode]) ) $config[$mode] = [];
                $config[$mode][$platform] = $cfg;
            }
        }

        $config_json = wp_json_encode($config);

        // Trata expiração
        $expires_at_db = null;
        if ( !empty($expires_at) ) {
            try {
                $dt = new DateTime($expires_at, wp_timezone());
                $expires_at_db = $dt->format('Y-m-d H:i:s');
            } catch (Exception $e) {
                $expires_at_db = null;
            }
        }

        if ( $promo_id > 0 ) {
            // Update
            $wpdb->update(
                $tbl,
                [
                    'code'        => $code,
                    'name'        => $name,
                    'active'      => $active,
                    'config_json' => $config_json,
                    'expires_at'  => $expires_at_db,
                    'updated_at'  => current_time('mysql'),
                ],
                ['id' => $promo_id],
                ['%s','%s','%d','%s','%s','%s'],
                ['%d']
            );
        } else {
            // Insert
            $wpdb->insert(
                $tbl,
                [
                    'code'        => $code,
                    'name'        => $name,
                    'active'      => $active,
                    'config_json' => $config_json,
                    'expires_at'  => $expires_at_db,
                    'created_at'  => current_time('mysql'),
                    'updated_at'  => current_time('mysql'),
                ],
                ['%s','%s','%d','%s','%s','%s','%s']
            );
        }

        wp_redirect( add_query_arg([
            'page'         => 'coins-selector-promos',
            'promo_saved'  => '1',
        ], admin_url('admin.php')) );
        exit;
    }

    /** Deletar promoção */
    public static function handle_promo_delete() {
        if ( ! isset($_GET['cs_delete_promo']) ) return;
        if ( ! current_user_can('manage_options') ) return;

        $id = (int) $_GET['cs_delete_promo'];
        if ( $id <= 0 ) return;

        check_admin_referer('cs_delete_promo_' . $id);

        global $wpdb;
        $tbl = CS_Core::table_promos();
        $wpdb->delete($tbl, ['id' => $id], ['%d']);

        wp_redirect( add_query_arg([
            'page'          => 'coins-selector-promos',
            'promo_deleted' => '1',
        ], admin_url('admin.php')) );
        exit;
    }

    /** Toggle ativo/inativo */
    public static function handle_promo_toggle() {
        if ( ! isset($_GET['cs_toggle_promo']) ) return;
        if ( ! current_user_can('manage_options') ) return;

        $id = (int) $_GET['cs_toggle_promo'];
        if ( $id <= 0 ) return;

        check_admin_referer('cs_toggle_promo_' . $id);

        global $wpdb;
        $tbl = CS_Core::table_promos();

        $current = $wpdb->get_var( $wpdb->prepare(
            "SELECT active FROM $tbl WHERE id = %d", $id
        ));

        $new_status = ($current == 1) ? 0 : 1;
        $wpdb->update($tbl, ['active' => $new_status], ['id' => $id], ['%d'], ['%d']);

        wp_redirect( add_query_arg([
            'page'          => 'coins-selector-promos',
            'promo_toggled' => '1',
        ], admin_url('admin.php')) );
        exit;
    }

    /* ================================================================
     * RENDER PAGES
     * ================================================================ */

    public static function render_page() {
        if ( ! current_user_can('manage_options') ) return;

        $modes = ['lance' => 'Lance', 'sniper' => 'Sniper'];
        $platforms = ['ps' => 'PlayStation', 'xbox' => 'Xbox', 'pc' => 'PC'];

        $get = function($mode,$pf,$key,$default=''){
            $cfg = CS_Core::get_config($mode,$pf);
            return isset($cfg[$key]) ? $cfg[$key] : $default;
        };

        $pending = self::get_pending_schedules();
        ?>
        <div class="wrap">
            <h1>Coins Selector — Configurações</h1>

            <?php if ( isset($_GET['updated']) ) : ?>
                <div class="updated notice"><p>Configurações salvas.</p></div>
            <?php endif; ?>

            <?php if ( isset($_GET['cs_sched']) ) : ?>
                <div class="updated notice"><p>Agendamento criado. O set atual será aplicado na data/hora escolhida.</p></div>
            <?php endif; ?>

            <?php if ( isset($_GET['cs_sched_cancelled']) ) : ?>
                <div class="updated notice notice-warning"><p>Agendamento cancelado.</p></div>
            <?php endif; ?>

            <?php if ( isset($_GET['cs_sched_error']) ) : ?>
                <div class="error notice"><p>Não foi possível criar o agendamento. Verifique data e hora e tente novamente.</p></div>
            <?php endif; ?>

            <form method="post">
                <?php wp_nonce_field('cs_admin'); ?>
                <input type="hidden" name="cs_admin_save" value="1" />

                <h2>Preços, Limites, 50k e Bônus</h2>
                <p>
                    Defina o preço base por 100k, habilite o 50k (preço fixo), ajuste limites/steps e,
                    opcionalmente, ative o <strong>bônus por 100k</strong>.
                </p>

                <?php foreach ($modes as $mode => $label_mode): ?>
                    <h3><?php echo esc_html($label_mode); ?></h3>
                    <table class="widefat striped">
                        <thead>
                        <tr>
                            <th>Plataforma</th>
                            <th>Preço 100k</th>
                            <th>Bônus habilitado</th>
                            <th>Bônus por 100k</th>
                            <th>Condição bônus</th>
                            <th>A partir de (coins)</th>
                            <th>Bônus cond. por 100k</th>
                            <th>50k habilitado</th>
                            <th>Preço 50k</th>
                            <th>Mín (coins)</th>
                            <th>Máx (coins)</th>
                            <?php if ($mode === 'sniper'): ?>
                                <th>Limiar</th>
                                <th>Step &lt; limiar</th>
                                <th>Step ≥ limiar</th>
                            <?php else: ?>
                                <th>100k-metade</th>
                            <?php endif; ?>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($platforms as $pf => $label_pf): ?>
                            <?php
                            $thr_raw = (int) $get($mode,$pf,'bonus_cond_threshold',0);
                            $thr_display = $thr_raw > 0 ? CS_Core::format_coins_label($thr_raw) : '';
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html($label_pf); ?></strong></td>

                                <td>
                                    <input type="text"
                                           name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][price_100k]"
                                           value="<?php echo esc_attr($get($mode,$pf,'price_100k','0.00')); ?>" size="6" />
                                </td>

                                <td>
                                    <label>
                                        <input type="checkbox"
                                               name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][bonus_enabled]"
                                               <?php checked( (int)$get($mode,$pf,'bonus_enabled',0), 1 ); ?> />
                                        Ativar
                                    </label>
                                </td>

                                <td>
                                    <input type="number" step="1000" min="0"
                                           name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][bonus_per_100k]"
                                           value="<?php echo esc_attr($get($mode,$pf,'bonus_per_100k',0)); ?>" />
                                </td>

                                <td>
                                    <label>
                                        <input type="checkbox"
                                               name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][bonus_cond_enabled]"
                                               <?php checked( (int)$get($mode,$pf,'bonus_cond_enabled',0), 1 ); ?> />
                                        Ativar
                                    </label>
                                </td>

                                <td>
                                    <input type="text"
                                           placeholder="Ex.: 1kk, 2kk"
                                           name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][bonus_cond_threshold]"
                                           value="<?php echo esc_attr($thr_display); ?>" size="10" />
                                </td>

                                <td>
                                    <input type="number" step="1000" min="0"
                                           name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][bonus_cond_per_100k]"
                                           value="<?php echo esc_attr($get($mode,$pf,'bonus_cond_per_100k',0)); ?>" />
                                </td>

                                <td>
                                    <label>
                                        <input type="checkbox"
                                               name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][has_50k]"
                                               <?php checked( (int)$get($mode,$pf,'has_50k',0), 1 ); ?> />
                                        Ativar
                                    </label>
                                </td>

                                <td>
                                    <input type="text"
                                           name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][price_50k]"
                                           value="<?php echo esc_attr($get($mode,$pf,'price_50k','0.00')); ?>" size="6" />
                                </td>

                                <td>
                                    <input type="number" step="10000"
                                           name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][min_coins]"
                                           value="<?php echo esc_attr($get($mode,$pf,'min_coins',100000)); ?>" />
                                </td>

                                <td>
                                    <input type="number" step="10000"
                                           name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][max_coins]"
                                           value="<?php echo esc_attr($get($mode,$pf,'max_coins', ($mode==='lance'?2000000:50000000) )); ?>" />
                                </td>

                                <?php if ($mode === 'sniper'): ?>
                                    <td>
                                        <input type="number" step="100000"
                                               name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][sniper_threshold]"
                                               value="<?php echo esc_attr($get($mode,$pf,'sniper_threshold',10000000)); ?>" />
                                    </td>
                                    <td>
                                        <input type="number" step="10000"
                                               name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][step_below]"
                                               value="<?php echo esc_attr($get($mode,$pf,'step_below',100000)); ?>" />
                                    </td>
                                    <td>
                                        <input type="number" step="100000"
                                               name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][step_above]"
                                               value="<?php echo esc_attr($get($mode,$pf,'step_above',1000000)); ?>" />
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <input type="text" placeholder="150k, 2.5kk"
                                               name="cs_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][half_100k_csv]"
                                               value="<?php echo esc_attr($get($mode,$pf,'half_100k_csv','')); ?>" size="24" />
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endforeach; ?>

                <hr />

                <h2>Faixas de Preço por Volume</h2>
                <p>
                    Defina faixas de coins e o <strong>preço por 100k (R$)</strong> correspondente.
                    Quando o slider atingir uma faixa, o preço por 100k padrão é substituído pelo valor da faixa.
                    Sem faixas cadastradas, o <em>Preço 100k</em> da tabela acima é usado normalmente.
                    Faixas não se aplicam quando há promo ativa.
                </p>

                <style>
                .cs-tiers-wrap { margin-bottom: 20px; }
                .cs-tiers-wrap h4 { margin: 10px 0 4px; }
                .cs-tiers-wrap table { border-collapse: collapse; margin-bottom: 6px; }
                .cs-tiers-wrap th, .cs-tiers-wrap td { padding: 4px 8px; border: 1px solid #ccd0d4; font-size: 13px; }
                .cs-tiers-wrap th { background: #f0f0f1; }
                .cs-tier-remove { color: #a00; cursor: pointer; border: none; background: none; font-size: 15px; }
                </style>

                <?php foreach ($modes as $mode => $label_mode): ?>
                    <h3>Faixas — <?php echo esc_html($label_mode); ?></h3>
                    <div style="display:flex;flex-wrap:wrap;gap:20px;">
                    <?php foreach ($platforms as $pf => $label_pf): ?>
                        <?php $existing_tiers = CS_Core::get_tiers($mode, $pf); ?>
                        <div class="cs-tiers-wrap">
                            <h4><?php echo esc_html($label_pf); ?></h4>
                            <table id="cs-tiers-tbl-<?php echo esc_attr($mode); ?>-<?php echo esc_attr($pf); ?>">
                                <thead>
                                    <tr>
                                        <th>Coins Mín</th>
                                        <th>Coins Máx<br><small>(vazio = sem limite)</small></th>
                                        <th>Preço 100k (R$)</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($existing_tiers as $i => $tier): ?>
                                    <tr>
                                        <td>
                                            <input type="number" step="100000" min="1"
                                                   name="cs_tiers[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][<?php echo $i; ?>][coins_min]"
                                                   value="<?php echo esc_attr($tier['coins_min']); ?>"
                                                   style="width:100px;" />
                                        </td>
                                        <td>
                                            <input type="number" step="100000" min="0"
                                                   name="cs_tiers[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][<?php echo $i; ?>][coins_max]"
                                                   value="<?php echo esc_attr($tier['coins_max'] ?? ''); ?>"
                                                   placeholder="ilimitado"
                                                   style="width:100px;" />
                                        </td>
                                        <td>
                                            <input type="text"
                                                   name="cs_tiers[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][<?php echo $i; ?>][price_100k]"
                                                   value="<?php echo esc_attr(number_format((float)$tier['price_100k'], 2, '.', '')); ?>"
                                                   style="width:70px;" />
                                        </td>
                                        <td>
                                            <button type="button" class="cs-tier-remove"
                                                    onclick="this.closest('tr').remove();">×</button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <button type="button" class="button button-small"
                                    onclick="csAddTierRow('<?php echo esc_js($mode); ?>','<?php echo esc_js($pf); ?>');">
                                + Adicionar faixa
                            </button>
                        </div>
                    <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>

                <script>
                function csAddTierRow(mode, pf) {
                    var tbody = document.querySelector('#cs-tiers-tbl-' + mode + '-' + pf + ' tbody');
                    var idx   = tbody.querySelectorAll('tr').length;
                    var row   = document.createElement('tr');
                    var base  = 'cs_tiers[' + mode + '][' + pf + '][' + idx + ']';
                    row.innerHTML =
                        '<td><input type="number" step="100000" min="1" name="' + base + '[coins_min]" value="" style="width:100px;" /></td>' +
                        '<td><input type="number" step="100000" min="0" name="' + base + '[coins_max]" value="" placeholder="ilimitado" style="width:100px;" /></td>' +
                        '<td><input type="text" name="' + base + '[price_100k]" value="" style="width:70px;" /></td>' +
                        '<td><button type="button" class="cs-tier-remove" onclick="this.closest(\'tr\').remove();">×</button></td>';
                    tbody.appendChild(row);
                }
                </script>

                <h2>Formulário do Sniper</h2>
                <p>Selecione a página onde está o formulário que receberá <code>?token=...</code>.</p>
                <p>
                    <?php
                    wp_dropdown_pages([
                        'name'              => 'cs_sniper_form_page_id',
                        'echo'              => 1,
                        'show_option_none'  => '— Selecione uma página —',
                        'option_none_value' => '0',
                        'selected'          => (int) get_option('cs_sniper_form_page_id', 0)
                    ]);
                    ?>
                </p>

                <p>
                    <button type="submit" class="button button-primary" name="cs_admin_save" value="1">
                        Salvar configurações
                    </button>
                </p>

                <hr />

                <h2>Agendar mudança do set atual</h2>
                <p>
                    Ajuste os valores na tabela acima, escolha data/hora e clique em <strong>Agendar mudança</strong>.
                </p>

                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="cs_schedule_date">Data</label></th>
                        <td><input type="date" id="cs_schedule_date" name="cs_schedule_date" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="cs_schedule_time">Hora</label></th>
                        <td><input type="time" id="cs_schedule_time" name="cs_schedule_time" /></td>
                    </tr>
                </table>

                <p>
                    <button type="submit" class="button" name="cs_admin_schedule" value="1">
                        Agendar mudança
                    </button>
                </p>

                <?php if ( ! empty($pending) ) : ?>
                    <h2>Agendamentos futuros</h2>
                    <table class="widefat striped">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Execução</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($pending as $row) : ?>
                            <?php
                            $run_at_local = '';
                            if ( ! empty($row['run_at']) ) {
                                $run_at_local = get_date_from_gmt( $row['run_at'], 'd/m/Y H:i' );
                            }
                            $cancel_url = wp_nonce_url(
                                add_query_arg([
                                    'page'               => 'coins-selector',
                                    'cs_cancel_schedule' => (int)$row['id'],
                                ], admin_url('admin.php')),
                                'cs_cancel_schedule_' . (int)$row['id']
                            );
                            ?>
                            <tr>
                                <td><?php echo (int)$row['id']; ?></td>
                                <td><?php echo esc_html($run_at_local); ?></td>
                                <td><?php echo esc_html($row['status']); ?></td>
                                <td>
                                    <a href="<?php echo esc_url($cancel_url); ?>"
                                       onclick="return confirm('Cancelar este agendamento?');">
                                        Cancelar
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>

            </form>
        </div>
        <?php
    }

    /** ======== PÁGINA DE PROMOÇÕES ======== */
    public static function render_promos_page() {
        if ( ! current_user_can('manage_options') ) return;

        $modes = ['lance' => 'Buy Now', 'sniper' => 'Sniper'];
        $platforms = ['ps' => 'PlayStation', 'xbox' => 'Xbox', 'pc' => 'PC'];

        // Verifica se está editando
        $editing_promo = null;
        if ( isset($_GET['edit_promo']) ) {
            $edit_id = (int)$_GET['edit_promo'];
            if ( $edit_id > 0 ) {
                $editing_promo = CS_Core::get_promo_by_id($edit_id);
            }
        }

        // Lista de promoções existentes
        $all_promos = CS_Core::get_all_promos();

        // Helper para pegar valor do cupom ou config padrão
        $get_promo_val = function($promo, $mode, $pf, $key, $default = '') use ($editing_promo) {
            if ( $promo && isset($promo['config'][$mode][$pf][$key]) ) {
                return $promo['config'][$mode][$pf][$key];
            }
            // Se criando novo, pega da config padrão
            $cfg = CS_Core::get_config($mode, $pf);
            return isset($cfg[$key]) ? $cfg[$key] : $default;
        };

        // URL base onde o shortcode está (para gerar links)
        $shortcode_page_url = home_url('/'); // Pode ser configurável futuramente
        ?>
        <div class="wrap">
            <h1>Coins Selector — Promoções</h1>

            <?php if ( isset($_GET['promo_saved']) ) : ?>
                <div class="updated notice"><p>Promoção salva com sucesso!</p></div>
            <?php endif; ?>

            <?php if ( isset($_GET['promo_deleted']) ) : ?>
                <div class="updated notice notice-warning"><p>Promoção excluída.</p></div>
            <?php endif; ?>

            <?php if ( isset($_GET['promo_toggled']) ) : ?>
                <div class="updated notice"><p>Status da promoção alterado.</p></div>
            <?php endif; ?>

            <?php if ( isset($_GET['promo_error']) ) : ?>
                <div class="error notice">
                    <p>
                        <?php 
                        $err = $_GET['promo_error'];
                        if ($err === 'code_empty') echo 'O código do cupom não pode ser vazio.';
                        elseif ($err === 'code_exists') echo 'Já existe um cupom com este código.';
                        else echo 'Erro ao salvar a promoção.';
                        ?>
                    </p>
                </div>
            <?php endif; ?>

            <!-- LISTA DE PROMOÇÕES EXISTENTES -->
            <?php if ( !empty($all_promos) && !$editing_promo ) : ?>
                <h2>Promoções Cadastradas</h2>
                <table class="widefat striped">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Código</th>
                        <th>Nome</th>
                        <th>Status</th>
                        <th>Expira em</th>
                        <th>Link</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($all_promos as $promo) : ?>
                        <?php
                        $toggle_url = wp_nonce_url(
                            add_query_arg([
                                'page'            => 'coins-selector-promos',
                                'cs_toggle_promo' => (int)$promo['id'],
                            ], admin_url('admin.php')),
                            'cs_toggle_promo_' . (int)$promo['id']
                        );
                        $delete_url = wp_nonce_url(
                            add_query_arg([
                                'page'            => 'coins-selector-promos',
                                'cs_delete_promo' => (int)$promo['id'],
                            ], admin_url('admin.php')),
                            'cs_delete_promo_' . (int)$promo['id']
                        );
                        $edit_url = add_query_arg([
                            'page'       => 'coins-selector-promos',
                            'edit_promo' => (int)$promo['id'],
                        ], admin_url('admin.php'));

                        $promo_link = add_query_arg('promo', $promo['code'], $shortcode_page_url);

                        $expires = '';
                        if ( !empty($promo['expires_at']) && $promo['expires_at'] !== '0000-00-00 00:00:00' ) {
                            $expires = date_i18n('d/m/Y H:i', strtotime($promo['expires_at']));
                        }
                        ?>
                        <tr>
                            <td><?php echo (int)$promo['id']; ?></td>
                            <td><strong><?php echo esc_html($promo['code']); ?></strong></td>
                            <td><?php echo esc_html($promo['name']); ?></td>
                            <td>
                                <?php if ($promo['active']) : ?>
                                    <span style="color:green;">● Ativo</span>
                                <?php else : ?>
                                    <span style="color:gray;">○ Inativo</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $expires ?: '—'; ?></td>
                            <td>
                                <input type="text" readonly value="<?php echo esc_attr($promo_link); ?>" 
                                       style="width:250px;" onclick="this.select();" />
                            </td>
                            <td>
                                <a href="<?php echo esc_url($edit_url); ?>">Editar</a> |
                                <a href="<?php echo esc_url($toggle_url); ?>">
                                    <?php echo $promo['active'] ? 'Desativar' : 'Ativar'; ?>
                                </a> |
                                <a href="<?php echo esc_url($delete_url); ?>" 
                                   onclick="return confirm('Excluir esta promoção?');"
                                   style="color:red;">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <br>
            <?php endif; ?>

            <!-- FORMULÁRIO DE CRIAR/EDITAR -->
            <h2><?php echo $editing_promo ? 'Editar Promoção' : 'Criar Nova Promoção'; ?></h2>

            <?php if ($editing_promo) : ?>
                <p>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=coins-selector-promos')); ?>">&larr; Voltar para lista</a>
                </p>
            <?php endif; ?>

            <form method="post">
                <?php wp_nonce_field('cs_promo_admin'); ?>
                <input type="hidden" name="cs_promo_save" value="1" />
                <input type="hidden" name="promo_id" value="<?php echo $editing_promo ? (int)$editing_promo['id'] : 0; ?>" />

                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="promo_code">Código do Cupom *</label></th>
                        <td>
                            <input type="text" id="promo_code" name="promo_code" 
                                   value="<?php echo $editing_promo ? esc_attr($editing_promo['code']) : ''; ?>"
                                   style="text-transform:uppercase;" required
                                   placeholder="Ex: BLACKFRIDAY" />
                            <p class="description">Somente letras, números, hífen e underscore. Será convertido para maiúsculas.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="promo_name">Nome (opcional)</label></th>
                        <td>
                            <input type="text" id="promo_name" name="promo_name" 
                                   value="<?php echo $editing_promo ? esc_attr($editing_promo['name']) : ''; ?>"
                                   placeholder="Ex: Black Friday 2024" style="width:300px;" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="promo_active">Status</label></th>
                        <td>
                            <label>
                                <input type="checkbox" id="promo_active" name="promo_active" value="1"
                                       <?php checked(!$editing_promo || $editing_promo['active']); ?> />
                                Promoção ativa
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="promo_expires">Expira em (opcional)</label></th>
                        <td>
                            <input type="datetime-local" id="promo_expires" name="promo_expires"
                                   value="<?php 
                                       if ($editing_promo && !empty($editing_promo['expires_at']) && $editing_promo['expires_at'] !== '0000-00-00 00:00:00') {
                                           echo date('Y-m-d\TH:i', strtotime($editing_promo['expires_at']));
                                       }
                                   ?>" />
                            <p class="description">Deixe vazio para não expirar.</p>
                        </td>
                    </tr>
                </table>

                <h3>Configurações de Preços/Bônus da Promoção</h3>
                <p>Defina os valores especiais que serão aplicados quando o usuário usar este cupom.</p>

                <?php foreach ($modes as $mode => $label_mode): ?>
                    <h4><?php echo esc_html($label_mode); ?></h4>
                    <table class="widefat striped">
                        <thead>
                        <tr>
                            <th>Plataforma</th>
                            <th>Preço 100k</th>
                            <th>Bônus</th>
                            <th>Bônus/100k</th>
                            <th>Cond. Bônus</th>
                            <th>A partir de</th>
                            <th>Bônus cond.</th>
                            <th>50k</th>
                            <th>Preço 50k</th>
                            <th>Mín</th>
                            <th>Máx</th>
                            <?php if ($mode === 'sniper'): ?>
                                <th>Limiar</th>
                            <?php else: ?>
                                <th>Quebrados</th>
                            <?php endif; ?>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($platforms as $pf => $label_pf): ?>
                            <?php
                            $thr_raw = (int) $get_promo_val($editing_promo, $mode, $pf, 'bonus_cond_threshold', 0);
                            $thr_display = $thr_raw > 0 ? CS_Core::format_coins_label($thr_raw) : '';
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html($label_pf); ?></strong></td>
                                <td>
                                    <input type="text" size="6"
                                           name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][price_100k]"
                                           value="<?php echo esc_attr($get_promo_val($editing_promo, $mode, $pf, 'price_100k', '0.00')); ?>" />
                                </td>
                                <td>
                                    <input type="checkbox"
                                           name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][bonus_enabled]"
                                           <?php checked((int)$get_promo_val($editing_promo, $mode, $pf, 'bonus_enabled', 0), 1); ?> />
                                </td>
                                <td>
                                    <input type="number" step="1000" min="0" size="8"
                                           name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][bonus_per_100k]"
                                           value="<?php echo esc_attr($get_promo_val($editing_promo, $mode, $pf, 'bonus_per_100k', 0)); ?>" />
                                </td>
                                <td>
                                    <input type="checkbox"
                                           name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][bonus_cond_enabled]"
                                           <?php checked((int)$get_promo_val($editing_promo, $mode, $pf, 'bonus_cond_enabled', 0), 1); ?> />
                                </td>
                                <td>
                                    <input type="text" size="8"
                                           name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][bonus_cond_threshold]"
                                           value="<?php echo esc_attr($thr_display); ?>" 
                                           placeholder="1kk" />
                                </td>
                                <td>
                                    <input type="number" step="1000" min="0" size="8"
                                           name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][bonus_cond_per_100k]"
                                           value="<?php echo esc_attr($get_promo_val($editing_promo, $mode, $pf, 'bonus_cond_per_100k', 0)); ?>" />
                                </td>
                                <td>
                                    <input type="checkbox"
                                           name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][has_50k]"
                                           <?php checked((int)$get_promo_val($editing_promo, $mode, $pf, 'has_50k', 0), 1); ?> />
                                </td>
                                <td>
                                    <input type="text" size="6"
                                           name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][price_50k]"
                                           value="<?php echo esc_attr($get_promo_val($editing_promo, $mode, $pf, 'price_50k', '0.00')); ?>" />
                                </td>
                                <td>
                                    <input type="number" step="10000" size="8"
                                           name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][min_coins]"
                                           value="<?php echo esc_attr($get_promo_val($editing_promo, $mode, $pf, 'min_coins', 100000)); ?>" />
                                </td>
                                <td>
                                    <input type="number" step="10000" size="8"
                                           name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][max_coins]"
                                           value="<?php echo esc_attr($get_promo_val($editing_promo, $mode, $pf, 'max_coins', ($mode === 'lance' ? 2000000 : 50000000))); ?>" />
                                </td>
                                <?php if ($mode === 'sniper'): ?>
                                    <td>
                                        <input type="number" step="100000" size="8"
                                               name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][sniper_threshold]"
                                               value="<?php echo esc_attr($get_promo_val($editing_promo, $mode, $pf, 'sniper_threshold', 10000000)); ?>" />
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <input type="text" size="12"
                                               name="promo_config[<?php echo esc_attr($mode); ?>][<?php echo esc_attr($pf); ?>][half_100k_csv]"
                                               value="<?php echo esc_attr($get_promo_val($editing_promo, $mode, $pf, 'half_100k_csv', '')); ?>"
                                               placeholder="150k, 2.5kk" />
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endforeach; ?>

                <p style="margin-top:20px;">
                    <button type="submit" class="button button-primary">
                        <?php echo $editing_promo ? 'Atualizar Promoção' : 'Criar Promoção'; ?>
                    </button>
                </p>
            </form>

            <?php if (!$editing_promo && empty($all_promos)) : ?>
                <p><em>Nenhuma promoção cadastrada ainda.</em></p>
            <?php endif; ?>
        </div>
        <?php
    }
}

CS_Admin::boot();