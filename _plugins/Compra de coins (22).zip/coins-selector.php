<?php
/**
 * Plugin Name: Coins Selector (Slider + Checkout/Sniper)
 * Description: Slider de compra de coins com modos Lance e Sniper, cálculo dinâmico, bônus configurável e integração com WooCommerce/formulário.
 * Version:     1.3.0
 * Author:      Mateus Maverick
 * Text Domain: coins-selector
 */

if ( ! defined('ABSPATH') ) {
    exit;
}

define('CS_VERSION',        '1.3.0');
define('CS_PLUGIN_FILE',    __FILE__);
define('CS_PLUGIN_DIR',     plugin_dir_path(__FILE__));
define('CS_PLUGIN_URL',     plugin_dir_url(__FILE__));
define('CS_ASSETS_URL',     trailingslashit(CS_PLUGIN_URL . 'assets'));
define('CS_TPL_DIR',        trailingslashit(CS_PLUGIN_DIR . 'templates'));
define('CS_INC_DIR',        trailingslashit(CS_PLUGIN_DIR . 'inc'));
define('CS_NS',             'coins-selector/v1'); // namespace REST

// URL fixa do formulário do modo Sniper (sempre envia ?token=...)
// Pode ser sobrescrita em código definindo CS_SNIPER_FORM_URL antes deste arquivo.
if ( ! defined('CS_SNIPER_FORM_URL') ) {
    define('CS_SNIPER_FORM_URL', 'https://chamacoins.com.br/dme-form');
}

/**
 * Retorna versão baseada em filemtime para evitar cache agressivo.
 * Se o arquivo não existir, cai no fallback (CS_VERSION).
 */
if ( ! function_exists('cs_asset_version') ) {
    function cs_asset_version(string $relative_path, string $fallback = CS_VERSION): string {
        $relative_path = ltrim($relative_path, '/');
        $file = CS_PLUGIN_DIR . $relative_path;

        if ( file_exists($file) ) {
            return (string) filemtime($file);
        }

        return $fallback;
    }
}

// ===== Includes =====
require_once CS_INC_DIR . 'class-core.php';
require_once CS_INC_DIR . 'class-admin.php';
require_once CS_INC_DIR . 'class-rest.php';

// ===== Ativação / Desativação =====
register_activation_hook(__FILE__, ['CS_Admin','activate']);

/**
 * MUITO IMPORTANTE:
 * O hook do cron precisa ser registrado SEMPRE (front, admin, wp-cron),
 * por isso fica aqui no arquivo principal, fora de admin_init.
 */
add_action('cs_apply_scheduled_config', ['CS_Admin', 'cron_apply_scheduled_config'], 10, 1);

// ===== Inicialização =====
add_action('plugins_loaded', function () {
    // Garante que os hooks do WooCommerce estejam ativos também no checkout
    if ( function_exists('add_filter') ) {
        CS_Core::boot_wc_hooks();
    }
});

// ===== Shortcode =====
add_shortcode('coins_selector', function($atts = []) {

    // Enqueue com cache-buster por filemtime()
    $css_ver = cs_asset_version('assets/coins.css', CS_VERSION);
    $js_ver  = cs_asset_version('assets/coins.js',  CS_VERSION);

    wp_enqueue_style('cs-style', CS_ASSETS_URL . 'coins.css', [], $css_ver);
    wp_enqueue_script('cs-app',  CS_ASSETS_URL . 'coins.js',  ['wp-i18n'], $js_ver, true);

    // Detecta código de promoção na URL
    $promo_code = '';
    if ( isset($_GET['promo']) && ! empty($_GET['promo']) ) {
        $promo_code = sanitize_text_field( wp_unslash($_GET['promo']) );

        // Valida se o cupom existe e está ativo
        $promo_data = CS_Core::get_promo_by_code($promo_code);
        if ( ! $promo_data || empty($promo_data['active']) ) {
            $promo_code = ''; // Cupom inválido ou inativo, ignora
        }
    }

    // Localize/nonce para REST + UI
    wp_localize_script('cs-app', 'CSVARS', [
        'rest' => [
            'root'   => esc_url_raw( rest_url(CS_NS) ),
            'nonce'  => wp_create_nonce('wp_rest'),
        ],
        'i18n' => [
            'total'  => __('Total de FIFA Coins', 'coins-selector'),
            'finish' => __('Finalizar', 'coins-selector'),
        ],
        // Preferência de quantos marcadores principais queremos na régua
        'ui'  => [
            'majorLabels' => 8, // pode ajustar via filtro se quiser
        ],
        // Código do cupom (vazio se não houver)
        'promo' => $promo_code,
    ]);

    ob_start();
    include CS_TPL_DIR . 'shortcode.php';
    return ob_get_clean();
});
